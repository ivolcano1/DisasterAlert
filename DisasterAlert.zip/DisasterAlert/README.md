# حارس الأرض (Earth Guardian)

يراقب ويتوقع (بناءً على اتجاهات التغيّر) الزلازل والفيضانات والبراكين والعواصف وموجات الحر والبرد قرب موقعك، ويعرض خريطة أقمار صناعية (أمطار وسحب) من NASA GIBS. يعمل في الخلفية كل 15 دقيقة.

## 1) قبل أول نشر
- غيّر `applicationId` و`namespace` في `app/build.gradle.kts` إلى معرّف فريد خاص بك (مثل `com.yourname.disasteralert`)، وغيّر اسم المجلد `java/com/example/disasteralert` وسطر `package` في ملفات Kotlin بالمثل.
- ضع بريدك في `PRIVACY_POLICY.md` وانشره على رابط عام (مثلاً GitHub Pages)، فجوجل بلاي تطلب رابط سياسة خصوصية.

## 2) إنشاء مفتاح التوقيع (مرة واحدة، احتفظ به للأبد)
```
keytool -genkeypair -v -keystore release.jks -alias upload -keyalg RSA -keysize 2048 -validity 10000
base64 -w0 release.jks > release.b64     # على ويندوز: certutil -encode release.jks release.b64
```
في GitHub: Settings ← Secrets and variables ← Actions، أضف:
`KEYSTORE_BASE64` (محتوى release.b64) و`KEYSTORE_PASSWORD` و`KEY_ALIAS` (= upload) و`KEY_PASSWORD`.
لا ترفع ملف `release.jks` إلى المستودع أبداً.

## 3) البناء
ارفع المحتويات إلى `main` ← تبويب Actions. ستجد في Artifacts:
- `DisasterAlert-release-AAB-for-Google-Play` ← هذا الملف الذي ترفعه إلى Google Play Console.
- `DisasterAlert-debug-APK` ← للتجربة على هاتفك.

## 4) قائمة Google Play
- حساب مطوّر (رسوم 25$ لمرة واحدة).
- أيقونة 512×512 وصورة مميزة 1024×500 ولقطات شاشة.
- نموذج Data safety: الموقع التقريبي (يُشارك مع Open-Meteo لتقديم الخدمة)، بلا تشفير إضافي، بلا بيع.
- تصنيف المحتوى، والجمهور المستهدف (بالغون).
- صفحة الوصف تذكر أن التطبيق لا يمثل جهة حكومية ولا يغني عن التحذيرات الرسمية (تطبيقات الطوارئ تُراجَع بدقة).
- الحسابات الشخصية الجديدة تحتاج اختباراً مغلقاً بـ12 مختبراً لمدة 14 يوماً قبل الإنتاج.

## المصادر
USGS • Open-Meteo • NASA EONET • NASA GIBS • OpenStreetMap

## كيف تعمل التوقعات
- **الطقس:** هبوط الضغط 12 هكتوباسكال خلال 24 ساعة (عاصفة)، أمطار 60 مم/24 ساعة أو 25 مم/ساعة (سيول)، تراكم 150 مم خلال 5 أيام (تشبّع التربة)، حرارة 40°+ لثلاثة أيام (موجة حر)، ‎-3°‎ أو أقل ليومين (برد).
- **المناخ:** مقارنة توقعات الأسبوع القادم بمتوسط نفس الأيام في آخر 3 سنوات، وتنبيه عند فرق 7°م فأكثر.
- **الأرض:** هزات ارتدادية بعد زلزال 5.5+ خلال 300 كم، وتجمّع 10 هزات صغيرة فأكثر خلال 24 ساعة ضمن 100 كم. لا يمكن التنبؤ بموعد الزلزال علمياً؛ هذه إشارات لرفع الحذر فقط.
- الحدود قابلة للتعديل في `Checker.kt`.

## الأقسام
- **الرئيسية:** طقس المدينة المختارة، رادار متحرك بلون الحالة، رادار المخاطر الستة (زلازل، سيول، عواصف، حر، برد، براكين)، مخطط 24 ساعة، توقعات 7 أيام.
- **التنبيهات:** كل التنبيهات لكل مدنك مع فلترة بالقسم، وتمييز «حدث» و«توقع» و«رسمي».
- **الأقمار:** خريطة أمطار وسحب من NASA GIBS فوق مدينتك.
- **المدن:** بحث عن أي مدينة في العالم، موقعي (GPS)، ومدن شائعة (حتى 8 مدن).

## المصادر الإقليمية
- داخل أمريكا: تحذيرات NWS الرسمية (أعاصير قمعية، عواصف شتوية، حرارة، فيضانات...).
- عالمياً: GDACS (أعاصير مدارية، فيضانات، براكين). هذا المصدر اختياري؛ إن تغيّر تنسيقه يُتجاهل بصمت.
- لإضافة جهة رسمية لمنطقة أخرى (مثل MeteoAlarm لأوروبا) أضف دالة جديدة في `Checker.kt`.

---

# English

**Earth Guardian** monitors (and, from weather/seismic trends, gives early warnings for) earthquakes, floods, volcanoes, storms, heat waves and cold waves near your chosen cities, with a NASA GIBS satellite view (rain and clouds). Background checks run every 15 minutes. The app is fully bilingual (Arabic / English): it follows the device language by default and can be switched in *Cities → Settings → Language*.

Features: multi-city monitoring, US official NWS warnings, offline cache (last data is shown without internet), safety guide per hazard with emergency numbers, battery-optimisation tip, °C/°F.

Build & release steps are the same as above: change `applicationId`/`namespace`, add the four signing secrets (`KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`), push, then download the AAB from the Actions artifacts. Host `PRIVACY_POLICY.md` at a public URL and put your email in it.
