package com.example.disasteralert

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

const val MATCH = -1
const val WRAP = -2

/** هوية «حارس الأرض»: واجهة داكنة بأسلوب غرفة العمليات مع لمسات سماوية. */
object Ui {
    val BG = Color.parseColor("#0A1020")
    val SURFACE = Color.parseColor("#121B30")
    val SURFACE2 = Color.parseColor("#1A2540")
    val STROKE = Color.parseColor("#26335A")
    val TEXT = Color.parseColor("#EAF0FF")
    val DIM = Color.parseColor("#8EA0C8")
    val ACCENT = Color.parseColor("#28D7FF")
    val OK = Color.parseColor("#2EE6A6")
    val WATCH = Color.parseColor("#FFB547")
    val DANGER = Color.parseColor("#FF4D5E")
    val VIOLET = Color.parseColor("#8B7CFF")

    fun withAlpha(c: Int, a: Int): Int = Color.argb(a, Color.red(c), Color.green(c), Color.blue(c))
    fun levelColor(l: Int): Int = when (l) { 0 -> OK; 1 -> WATCH; else -> DANGER }
    fun levelText(l: Int): String = when (l) { 0 -> "آمن"; 1 -> "ترقّب"; else -> "خطر" }
}

fun Context.dp(x: Int): Int = (x * resources.displayMetrics.density + 0.5f).toInt()

fun Context.shape(color: Int, radiusDp: Int, strokeColor: Int = 0, strokeDp: Int = 1): GradientDrawable =
    GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
        if (strokeColor != 0) setStroke(dp(strokeDp), strokeColor)
    }

fun Context.tv(s: String, sp: Float, color: Int = Ui.TEXT, bold: Boolean = false): TextView =
    TextView(this).apply {
        text = s
        textSize = sp
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

fun Context.icon(res: Int, sizeDp: Int, tint: Int): ImageView =
    ImageView(this).apply {
        setImageResource(res)
        setColorFilter(tint)
        layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
    }

/** أيقونة داخل دائرة ملوّنة شبه شفافة. */
fun Context.badge(res: Int, color: Int, sizeDp: Int = 44): FrameLayout =
    FrameLayout(this).apply {
        background = shape(Ui.withAlpha(color, 40), sizeDp / 2)
        val inner = sizeDp * 5 / 11
        addView(icon(res, inner, color).apply {
            layoutParams = FrameLayout.LayoutParams(dp(inner), dp(inner), Gravity.CENTER)
        })
        layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
    }

/** s = هامش البداية (يمين في العربية)، e = هامش النهاية، t = أعلى، b = أسفل (كلها بوحدة dp). */
fun Context.lp(
    w: Int, h: Int, s: Int = 0, t: Int = 0, e: Int = 0, b: Int = 0, weight: Float = 0f
): LinearLayout.LayoutParams =
    LinearLayout.LayoutParams(w, h, weight).apply {
        topMargin = dp(t)
        bottomMargin = dp(b)
        marginStart = dp(s)
        marginEnd = dp(e)
    }

fun Context.col(padDp: Int = 0): LinearLayout =
    LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(padDp), dp(padDp), dp(padDp), dp(padDp))
    }

fun Context.row(): LinearLayout =
    LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
    }

fun Context.card(padDp: Int = 16): LinearLayout =
    col(padDp).apply { background = shape(Ui.SURFACE, 20, Ui.STROKE) }
