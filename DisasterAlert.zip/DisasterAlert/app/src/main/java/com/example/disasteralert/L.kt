package com.example.disasteralert

import android.content.Context
import java.util.Locale

/** نظام لغتين بسيط: العربية أو الإنجليزية، تلقائي حسب لغة الجهاز أو بحسب اختيار المستخدم. */
object L {
    @Volatile
    var ar: Boolean = true

    fun init(ctx: Context) {
        ar = when (pref(ctx)) {
            "ar" -> true
            "en" -> false
            else -> Locale.getDefault().language == "ar"
        }
    }

    fun pref(ctx: Context): String =
        ctx.getSharedPreferences("prefs", Context.MODE_PRIVATE).getString("lang", "auto") ?: "auto"

    fun setPref(ctx: Context, v: String) {
        ctx.getSharedPreferences("prefs", Context.MODE_PRIVATE).edit().putString("lang", v).apply()
    }

    fun t(a: String, e: String): String = if (ar) a else e
}
