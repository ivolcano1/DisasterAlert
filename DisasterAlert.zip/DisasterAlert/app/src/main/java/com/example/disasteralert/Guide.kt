package com.example.disasteralert

/** دليل السلامة لكل خطر + أرقام الطوارئ للدول التي نثق بأرقامها. إرشادات عامة وليست بديلاً عن تعليمات السلطات. */
object Guide {
    data class Section(val title: String, val items: List<String>)

    private fun t(a: String, e: String) = L.t(a, e)

    fun sections(h: Hazard): List<Section> = when (h) {
        Hazard.QUAKE -> listOf(
            Section(t("أثناء الزلزال", "During an earthquake"), listOf(
                t("اخفض جسمك، واحتمِ تحت طاولة قوية أو بجانب جدار داخلي، وتمسّك حتى يتوقف الاهتزاز.",
                    "Drop to the ground, take cover under a sturdy table or beside an interior wall, and hold on until the shaking stops."),
                t("ابتعد عن النوافذ والمرايا والأثاث الثقيل. لا تركض للخارج أثناء الاهتزاز.",
                    "Stay away from windows, mirrors and heavy furniture. Do not run outside while the ground is shaking."),
                t("إن كنت في الخارج فتوجّه إلى مكان مفتوح بعيداً عن المباني وأعمدة الكهرباء.",
                    "If outdoors, move to an open area away from buildings and power lines."),
                t("في السيارة: أوقفها في مكان آمن بعيداً عن الجسور والأنفاق وابقَ داخلها.",
                    "In a car: stop in a safe place away from bridges and tunnels and stay inside.")
            )),
            Section(t("بعد الزلزال", "Afterwards"), listOf(
                t("توقّع هزات ارتدادية. اخرج بهدوء من المبنى إن كان متضرراً.",
                    "Expect aftershocks. Leave damaged buildings calmly."),
                t("إذا شممت رائحة غاز فافتح النوافذ واخرج، ولا تُشعل أي لهب ولا تستخدم المفاتيح الكهربائية.",
                    "If you smell gas, open windows and leave; avoid flames and electrical switches."),
                t("لا تستخدم المصاعد. أرسل رسائل نصية بدل المكالمات لإبقاء الشبكة متاحة للطوارئ.",
                    "Do not use elevators. Send text messages instead of calling to keep networks free for emergencies."),
                t("على السواحل: إذا صدر تحذير تسونامي فابتعد عن الشاطئ إلى مكان مرتفع.",
                    "On coasts: if a tsunami warning is issued, move inland and uphill.")
            ))
        )
        Hazard.FLOOD -> listOf(
            Section(t("أثناء الفيضان", "During a flood"), listOf(
                t("انتقل فوراً إلى مكان مرتفع ولا تنتظر وصول المياه.",
                    "Move to higher ground immediately; do not wait for water to arrive."),
                t("لا تمشِ ولا تقُد عبر مياه السيول: 15 سم من المياه المتحركة قد تُسقط شخصاً، و30 سم قد تجرف سيارة.",
                    "Never walk or drive through floodwater: 15 cm (6 in) of moving water can knock you down and 30 cm (1 ft) can carry away a car."),
                t("ابتعد عن الأودية ومجاري السيول والأنفاق، حتى لو كانت السماء صافية عندك.",
                    "Stay away from wadis, streams and underpasses, even if it is not raining where you are."),
                t("إن دخلت المياه المنزل فافصل الكهرباء والغاز من المصدر إن كان ذلك آمناً.",
                    "If water enters your home, switch off electricity and gas at the mains if it is safe to do so.")
            )),
            Section(t("بعد الفيضان", "Afterwards"), listOf(
                t("تجنّب المياه الراكدة فقد تكون ملوثة أو بها تيار كهربائي.",
                    "Avoid standing floodwater; it may be contaminated or electrically charged."),
                t("اشرب ماءً معبأً حتى تتأكد من سلامة مياه الشبكة.",
                    "Drink bottled water until tap water is confirmed safe."),
                t("صوّر الأضرار قبل التنظيف، ولا تدخل مبنى متضرراً قبل التأكد من سلامته.",
                    "Photograph damage before cleaning up, and do not enter damaged buildings until they are declared safe.")
            ))
        )
        Hazard.STORM -> listOf(
            Section(t("أثناء العاصفة", "During the storm"), listOf(
                t("ابقَ داخل مبنى متين بعيداً عن النوافذ، واختر الطابق الأسفل وغرفة داخلية عند احتمال الأعاصير.",
                    "Stay inside a solid building away from windows; choose the lowest floor and an interior room if a tornado is possible."),
                t("ثبّت أو أدخل الأشياء الخارجية الخفيفة (أثاث، لافتات) التي قد تطير بالرياح.",
                    "Secure or bring in loose outdoor objects that the wind could throw."),
                t("أثناء العواصف الرعدية ابتعد عن الأماكن المفتوحة والأشجار المنفردة والمياه.",
                    "In thunderstorms avoid open areas, isolated trees and water."),
                t("لا تقترب من أسلاك الكهرباء الساقطة واعتبرها حيّة دائماً.",
                    "Stay away from fallen power lines and treat them as live.")
            )),
            Section(t("استعد", "Prepare"), listOf(
                t("اشحن هاتفك ومصابيحك وجهّز ماءً وطعاماً وأدوية لعدة أيام.",
                    "Charge phones and torches; keep water, food and medicines for several days."),
                t("اعرف طريق الإخلاء ومكان الملجأ والتزم بأوامر الجهات الرسمية فوراً.",
                    "Know your evacuation route and shelter, and follow official evacuation orders promptly."),
                t("أجّل السفر والرحلات البحرية أثناء العاصفة.",
                    "Postpone travel and sea trips during the storm.")
            ))
        )
        Hazard.HEAT -> listOf(
            Section(t("نصائح للحر الشديد", "Extreme heat advice"), listOf(
                t("اشرب الماء بانتظام حتى دون عطش، وقلّل الكافيين والكحول.",
                    "Drink water regularly even if not thirsty; limit caffeine and alcohol."),
                t("تجنّب الشمس والنشاط الشاق من الظهر حتى العصر، وابقَ في مكان مظلل أو مكيّف.",
                    "Avoid the sun and strenuous activity at midday; stay in shade or air conditioning."),
                t("ارتدِ ملابس خفيفة فاتحة وقبعة، واستخدم واقي الشمس.",
                    "Wear light-coloured loose clothing and a hat; use sunscreen."),
                t("لا تترك طفلاً أو حيواناً أليفاً في سيارة مغلقة أبداً.",
                    "Never leave a child or pet in a parked car."),
                t("علامات ضربة الشمس: حرارة مرتفعة، دوخة، ارتباك، توقف التعرق. اتصل بالإسعاف فوراً وبرّد الشخص.",
                    "Heat-stroke signs: very high temperature, dizziness, confusion, no sweating. Call emergency services and cool the person."),
                t("تفقّد كبار السن والمرضى والأطفال.",
                    "Check on elderly neighbours, children and people with chronic illness.")
            ))
        )
        Hazard.COLD -> listOf(
            Section(t("نصائح للبرد القارس", "Extreme cold advice"), listOf(
                t("ارتدِ طبقات من الملابس الدافئة وغطِّ الرأس واليدين والقدمين.",
                    "Dress in warm layers and cover head, hands and feet."),
                t("لا تستخدم مدافئ الفحم أو الغاز أو المولدات داخل أماكن مغلقة: خطر التسمم بأول أكسيد الكربون.",
                    "Never run charcoal heaters, gas stoves or generators in closed spaces: carbon monoxide risk."),
                t("قلّل البقاء في الخارج. علامات قضمة الصقيع: خدر وجلد شاحب وصلب.",
                    "Limit time outdoors. Frostbite signs: numbness and pale, hard skin."),
                t("جهّز السيارة (بطانية، ماء، شاحن) وتجنّب القيادة على الجليد إن أمكن.",
                    "Prepare your car (blanket, water, charger) and avoid driving on ice if possible."),
                t("تفقّد كبار السن ومن لا مأوى لهم، وأدخل الحيوانات الأليفة.",
                    "Check on elderly neighbours and people without shelter; bring pets indoors.")
            ))
        )
        Hazard.VOLCANO -> listOf(
            Section(t("نصائح للنشاط البركاني", "Volcanic activity advice"), listOf(
                t("التزم فوراً بأوامر الإخلاء الرسمية وابتعد عن الوديان ومجاري الأنهار قرب البركان.",
                    "Follow official evacuation orders immediately; stay away from valleys and rivers near the volcano."),
                t("عند سقوط الرماد: ابقَ في الداخل وأغلق النوافذ، واستخدم كمامة N95 أو قماشاً مبللاً.",
                    "During ashfall stay indoors, close windows, and wear an N95 mask or a damp cloth."),
                t("احمِ عينيك ولا تقُد في الرماد الكثيف فهو يتلف المحرك ويحجب الرؤية.",
                    "Protect your eyes; avoid driving in heavy ash as it damages engines and cuts visibility."),
                t("غطِّ خزانات المياه وأبعد الحيوانات عن الرماد.",
                    "Cover water tanks and keep animals away from ash.")
            ))
        )
    }

    private val eu = setOf(
        "FR", "DE", "IT", "ES", "GR", "PT", "NL", "BE", "AT", "IE", "SE", "FI", "PL", "DK", "CZ",
        "HU", "RO", "BG", "HR", "SK", "SI", "LT", "LV", "EE", "LU", "CY", "MT", "TR", "IN"
    )

    /** أرقام نثق بها فقط. للدول الأخرى نعرض تنبيهاً لمراجعة الرقم المحلي. */
    fun emergency(cc: String): List<Pair<String, String>>? {
        val police = t("الشرطة", "Police")
        val amb = t("الإسعاف", "Ambulance")
        val fire = t("الإطفاء", "Fire")
        val civil = t("الحماية المدنية", "Civil protection")
        val code = cc.uppercase()
        return when {
            code == "EG" -> listOf(police to "122", amb to "123", fire to "180")
            code == "SA" -> listOf(t("الطوارئ الموحّد", "Unified emergency") to "911", amb to "997", civil to "998")
            code == "AE" -> listOf(police to "999", amb to "998", fire to "997")
            code == "US" || code == "CA" || code == "MX" || code == "PH" ->
                listOf(t("الطوارئ", "Emergency") to "911")
            code == "GB" -> listOf(t("الطوارئ", "Emergency") to "999")
            code == "JP" -> listOf(police to "110", t("الإطفاء والإسعاف", "Fire & ambulance") to "119")
            code == "AU" -> listOf(t("الطوارئ", "Emergency") to "000")
            code == "MA" -> listOf(police to "19", amb + " / " + civil to "15")
            code == "TN" -> listOf(police to "197", amb to "190", civil to "198")
            code == "DZ" -> listOf(police to "17", civil to "14")
            code == "LB" -> listOf(police to "112", civil to "125", t("الصليب الأحمر", "Red Cross") to "140")
            code in eu -> listOf(t("الطوارئ", "Emergency") to "112")
            else -> null
        }
    }
}
