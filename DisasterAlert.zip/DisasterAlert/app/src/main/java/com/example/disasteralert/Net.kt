package com.example.disasteralert

import java.net.HttpURLConnection
import java.net.URL

object Net {
    private val cache = HashMap<String, Pair<Long, String>>()

    fun get(url: String, accept: String? = null): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 25000
        c.setRequestProperty("User-Agent", "EarthGuardianApp/1.0 (Android)")
        if (accept != null) c.setRequestProperty("Accept", accept)
        return try {
            if (c.responseCode !in 200..299) throw java.io.IOException("HTTP ${c.responseCode}")
            c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    /** للمصادر العالمية المشتركة بين المدن (USGS, EONET, GDACS) حتى لا نكرر الطلب لكل مدينة. */
    @Synchronized
    fun getCached(url: String, ttlMs: Long): String {
        val now = System.currentTimeMillis()
        val hit = cache[url]
        if (hit != null && now - hit.first < ttlMs) return hit.second
        val s = get(url)
        cache[url] = Pair(now, s)
        return s
    }
}
