package com.example.disasteralert

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** تخزين المدن المحفوظة وموقع GPS والإعدادات على الجهاز فقط. */
object Store {
    const val MAX_SAVED = 8

    private fun p(ctx: Context) = ctx.getSharedPreferences("prefs", Context.MODE_PRIVATE)

    fun saved(ctx: Context): List<City> {
        val a = JSONArray(p(ctx).getString("cities", "[]") ?: "[]")
        val out = mutableListOf<City>()
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            out += City(o.getString("n"), o.optString("c"), o.getDouble("la"), o.getDouble("lo"), false, o.optString("cc"))
        }
        return out
    }

    private fun setSaved(ctx: Context, list: List<City>) {
        val a = JSONArray()
        list.forEach {
            a.put(
                JSONObject().put("n", it.name).put("c", it.country).put("la", it.lat)
                    .put("lo", it.lon).put("cc", it.cc)
            )
        }
        p(ctx).edit().putString("cities", a.toString()).apply()
    }

    /** يُرجع false إذا بلغنا الحد الأقصى. */
    fun add(ctx: Context, city: City): Boolean {
        val list = saved(ctx).toMutableList()
        if (list.any { it.key == city.key }) return true
        if (list.size >= MAX_SAVED) return false
        list += city
        setSaved(ctx, list)
        return true
    }

    fun remove(ctx: Context, city: City) {
        if (city.gps) {
            p(ctx).edit().remove("lat").remove("lon").remove("gpsName").remove("gpsCountry").remove("gpsCc").apply()
        } else {
            setSaved(ctx, saved(ctx).filter { it.key != city.key })
        }
    }

    fun gps(ctx: Context): City? {
        val s = p(ctx)
        if (!s.contains("lat") || !s.contains("lon")) return null
        val nm = s.getString("gpsName", "") ?: ""
        return City(
            if (nm.isBlank()) L.t("موقعي الحالي", "My location") else nm,
            s.getString("gpsCountry", "") ?: "",
            java.lang.Double.longBitsToDouble(s.getLong("lat", 0)),
            java.lang.Double.longBitsToDouble(s.getLong("lon", 0)),
            true,
            s.getString("gpsCc", "") ?: ""
        )
    }

    fun setGps(ctx: Context, lat: Double, lon: Double) {
        p(ctx).edit()
            .putLong("lat", java.lang.Double.doubleToLongBits(lat))
            .putLong("lon", java.lang.Double.doubleToLongBits(lon))
            .apply()
    }

    fun setGpsName(ctx: Context, name: String, country: String, cc: String) {
        p(ctx).edit().putString("gpsName", name).putString("gpsCountry", country).putString("gpsCc", cc).apply()
    }

    // ---- إعدادات ----
    fun forecastNotifs(ctx: Context) = p(ctx).getBoolean("notifForecast", true)
    fun setForecastNotifs(ctx: Context, v: Boolean) = p(ctx).edit().putBoolean("notifForecast", v).apply()
    fun useF(ctx: Context) = p(ctx).getBoolean("useF", false)
    fun setUseF(ctx: Context, v: Boolean) = p(ctx).edit().putBoolean("useF", v).apply()
    fun battTipDismissed(ctx: Context) = p(ctx).getBoolean("battTip", false)
    fun dismissBattTip(ctx: Context) = p(ctx).edit().putBoolean("battTip", true).apply()

    fun all(ctx: Context): List<City> = listOfNotNull(gps(ctx)) + saved(ctx)

    fun setSelected(ctx: Context, city: City) {
        p(ctx).edit().putString("sel", city.key).apply()
    }

    fun selected(ctx: Context): City? {
        val all = all(ctx)
        val k = p(ctx).getString("sel", null)
        return all.firstOrNull { it.key == k } ?: all.firstOrNull()
    }
}
