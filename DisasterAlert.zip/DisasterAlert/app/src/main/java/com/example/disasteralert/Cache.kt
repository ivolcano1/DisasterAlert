package com.example.disasteralert

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** يحفظ آخر تقرير وطقس لكل مدينة على الجهاز، لعرضها عند انقطاع الإنترنت. */
object Cache {
    private fun p(ctx: Context) = ctx.getSharedPreferences("cache", Context.MODE_PRIVATE)

    fun save(ctx: Context, key: String, rep: Report?, wx: WeatherData?) {
        val e = p(ctx).edit()
        if (rep != null) {
            val alerts = JSONArray()
            rep.alerts.forEach {
                alerts.put(
                    JSONObject().put("id", it.id).put("h", it.hazard.name).put("ti", it.title)
                        .put("b", it.body).put("f", it.forecast).put("o", it.official)
                )
            }
            val failed = JSONArray()
            rep.failed.forEach { failed.put(it) }
            e.putString(
                "r_$key",
                JSONObject().put("t", rep.time).put("att", rep.attempted).put("fl", failed).put("al", alerts).toString()
            )
        }
        if (wx != null) {
            val hours = JSONArray()
            wx.hourTemps.forEach { hours.put(it) }
            val days = JSONArray()
            wx.days.forEach {
                days.put(
                    JSONObject().put("d", it.date).put("mx", it.tMax).put("mn", it.tMin)
                        .put("c", it.code).put("r", it.rain)
                )
            }
            val n = wx.now
            e.putString(
                "w_$key",
                JSONObject()
                    .put("now", JSONObject().put("t", n.temp).put("f", n.feels).put("h", n.humidity)
                        .put("w", n.wind).put("p", n.pressure).put("c", n.code).put("d", n.isDay))
                    .put("hrs", hours).put("sh", wx.startHour).put("days", days).toString()
            )
        }
        e.apply()
    }

    /** يملأ AppState من الذاكرة الدائمة للمدن الحالية. */
    fun loadAll(ctx: Context, cities: List<City>) {
        val s = p(ctx)
        for (c in cities) {
            try {
                s.getString("r_" + c.key, null)?.let { str ->
                    val o = JSONObject(str)
                    val al = o.getJSONArray("al")
                    val alerts = mutableListOf<Alert>()
                    for (i in 0 until al.length()) {
                        val a = al.getJSONObject(i)
                        alerts += Alert(
                            a.getString("id"), Hazard.valueOf(a.getString("h")), a.getString("ti"),
                            a.getString("b"), a.optBoolean("f"), a.optBoolean("o")
                        )
                    }
                    val fl = o.getJSONArray("fl")
                    val failed = (0 until fl.length()).map { fl.getString(it) }
                    AppState.reports[c.key] = Report(c, alerts, failed, o.getInt("att"), o.getLong("t"))
                }
                s.getString("w_" + c.key, null)?.let { str ->
                    val o = JSONObject(str)
                    val n = o.getJSONObject("now")
                    val now = NowW(
                        n.getDouble("t"), n.getDouble("f"), n.getInt("h"), n.getDouble("w"),
                        n.getDouble("p"), n.getInt("c"), n.getBoolean("d")
                    )
                    val hr = o.getJSONArray("hrs")
                    val hours = (0 until hr.length()).map { hr.getDouble(it) }
                    val dj = o.getJSONArray("days")
                    val days = (0 until dj.length()).map {
                        val d = dj.getJSONObject(it)
                        DayW(d.getString("d"), d.getDouble("mx"), d.getDouble("mn"), d.getInt("c"), d.getDouble("r"))
                    }
                    AppState.weather[c.key] = WeatherData(now, hours, o.getInt("sh"), days)
                }
            } catch (_: Exception) {
                // بيانات محفوظة تالفة: نتجاهلها
            }
        }
    }
}
