package com.example.disasteralert

import java.util.Locale

enum class Hazard(
    private val ar: String, private val en: String,
    private val sAr: String, private val sEn: String,
    val icon: Int
) {
    QUAKE("الزلازل", "Earthquakes", "زلازل", "Quakes", R.drawable.ic_h_quake),
    FLOOD("الفيضانات والأمطار", "Floods & heavy rain", "سيول", "Floods", R.drawable.ic_h_flood),
    STORM("العواصف والأعاصير", "Storms & cyclones", "عواصف", "Storms", R.drawable.ic_h_storm),
    HEAT("الحر الشديد", "Extreme heat", "حر", "Heat", R.drawable.ic_h_heat),
    COLD("البرد والثلوج", "Cold & snow", "برد", "Cold", R.drawable.ic_h_cold),
    VOLCANO("البراكين", "Volcanoes", "براكين", "Volcano", R.drawable.ic_h_volcano);

    val label: String get() = L.t(ar, en)
    val short: String get() = L.t(sAr, sEn)
}

data class City(
    val name: String,
    val country: String,
    val lat: Double,
    val lon: Double,
    val gps: Boolean = false,
    val cc: String = ""        // رمز الدولة ISO مثل EG أو US (لأرقام الطوارئ)
) {
    val key: String get() = String.format(Locale.US, "%.2f,%.2f", lat, lon)
}

/** forecast = توقع/إنذار مبكر مبني على اتجاه. official = تحذير صادر عن جهة رسمية. */
data class Alert(
    val id: String,
    val hazard: Hazard,
    val title: String,
    val body: String,
    val forecast: Boolean = false,
    val official: Boolean = false
)

/** attempted = عدد المصادر الأساسية التي جرّبناها، failed = التي فشلت منها. */
data class Report(
    val city: City,
    val alerts: List<Alert>,
    val failed: List<String>,
    val attempted: Int,
    val time: Long = System.currentTimeMillis()
) {
    /** 0 آمن، 1 ترقّب (توقع)، 2 خطر (حدث/تحذير) */
    fun level(h: Hazard): Int {
        val l = alerts.filter { it.hazard == h }
        return when {
            l.any { !it.forecast } -> 2
            l.any { it.forecast } -> 1
            else -> 0
        }
    }

    fun overall(): Int = Hazard.values().maxOf { level(it) }
    fun allFailed(): Boolean = attempted > 0 && failed.size >= attempted
}

/** ذاكرة مؤقتة داخل التطبيق لآخر النتائج. تُستخدم من الواجهة (الخيط الرئيسي) فقط. */
object AppState {
    val reports = HashMap<String, Report>()
    val weather = HashMap<String, WeatherData>()
}

object Popular {
    private data class P(
        val ar: String, val en: String, val car: String, val cen: String,
        val cc: String, val lat: Double, val lon: Double
    )

    private val data = listOf(
        P("القاهرة", "Cairo", "مصر", "Egypt", "EG", 30.044, 31.236),
        P("الإسكندرية", "Alexandria", "مصر", "Egypt", "EG", 31.200, 29.919),
        P("الرياض", "Riyadh", "السعودية", "Saudi Arabia", "SA", 24.714, 46.675),
        P("جدة", "Jeddah", "السعودية", "Saudi Arabia", "SA", 21.543, 39.173),
        P("دبي", "Dubai", "الإمارات", "UAE", "AE", 25.205, 55.271),
        P("بغداد", "Baghdad", "العراق", "Iraq", "IQ", 33.315, 44.366),
        P("عمّان", "Amman", "الأردن", "Jordan", "JO", 31.954, 35.910),
        P("بيروت", "Beirut", "لبنان", "Lebanon", "LB", 33.894, 35.502),
        P("الدار البيضاء", "Casablanca", "المغرب", "Morocco", "MA", 33.573, -7.590),
        P("تونس", "Tunis", "تونس", "Tunisia", "TN", 36.806, 10.182),
        P("الجزائر", "Algiers", "الجزائر", "Algeria", "DZ", 36.753, 3.059),
        P("إسطنبول", "Istanbul", "تركيا", "Türkiye", "TR", 41.009, 28.978),
        P("لندن", "London", "بريطانيا", "United Kingdom", "GB", 51.507, -0.128),
        P("باريس", "Paris", "فرنسا", "France", "FR", 48.857, 2.352),
        P("نيويورك", "New York", "أمريكا", "United States", "US", 40.713, -74.006),
        P("لوس أنجلوس", "Los Angeles", "أمريكا", "United States", "US", 34.052, -118.244),
        P("ميامي", "Miami", "أمريكا", "United States", "US", 25.762, -80.192),
        P("هيوستن", "Houston", "أمريكا", "United States", "US", 29.760, -95.370),
        P("نيو أورلينز", "New Orleans", "أمريكا", "United States", "US", 29.951, -90.072),
        P("أوكلاهوما سيتي", "Oklahoma City", "أمريكا", "United States", "US", 35.468, -97.516),
        P("طوكيو", "Tokyo", "اليابان", "Japan", "JP", 35.682, 139.759),
        P("مانيلا", "Manila", "الفلبين", "Philippines", "PH", 14.600, 120.984),
        P("جاكرتا", "Jakarta", "إندونيسيا", "Indonesia", "ID", -6.209, 106.846),
        P("مدينة مكسيكو", "Mexico City", "المكسيك", "Mexico", "MX", 19.433, -99.133)
    )

    fun list(): List<City> =
        data.map { City(L.t(it.ar, it.en), L.t(it.car, it.cen), it.lat, it.lon, false, it.cc) }
}
