package com.example.disasteralert

import java.util.Locale

enum class Hazard(val ar: String, val short: String, val icon: Int) {
    QUAKE("الزلازل", "زلازل", R.drawable.ic_h_quake),
    FLOOD("الفيضانات والأمطار", "سيول", R.drawable.ic_h_flood),
    STORM("العواصف والأعاصير", "عواصف", R.drawable.ic_h_storm),
    HEAT("الحر الشديد", "حر", R.drawable.ic_h_heat),
    COLD("البرد والثلوج", "برد", R.drawable.ic_h_cold),
    VOLCANO("البراكين", "براكين", R.drawable.ic_h_volcano)
}

data class City(
    val name: String,
    val country: String,
    val lat: Double,
    val lon: Double,
    val gps: Boolean = false
) {
    val key: String get() = String.format(Locale.US, "%.2f,%.2f", lat, lon)
}

/** forecast = توقع/إنذار مبكر مبني على اتجاه. official = تحذير صادر عن جهة رسمية. */
data class Alert(
    val id: String,
    val hazard: Hazard,
    val title: String,
    val body: String,
    val forecast: Boolean = false,
    val official: Boolean = false
)

/** attempted = عدد المصادر الأساسية التي جرّبناها، failed = التي فشلت منها. */
data class Report(
    val city: City,
    val alerts: List<Alert>,
    val failed: List<String>,
    val attempted: Int,
    val time: Long = System.currentTimeMillis()
) {
    /** 0 آمن، 1 ترقّب (توقع)، 2 خطر (حدث/تحذير) */
    fun level(h: Hazard): Int {
        val l = alerts.filter { it.hazard == h }
        return when {
            l.any { !it.forecast } -> 2
            l.any { it.forecast } -> 1
            else -> 0
        }
    }

    fun overall(): Int = Hazard.values().maxOf { level(it) }
    fun allFailed(): Boolean = attempted > 0 && failed.size >= attempted
}

/** ذاكرة مؤقتة داخل التطبيق لآخر النتائج. تُستخدم من الواجهة (الخيط الرئيسي) فقط. */
object AppState {
    val reports = HashMap<String, Report>()
    val weather = HashMap<String, WeatherData>()
}

object Popular {
    val cities = listOf(
        City("القاهرة", "مصر", 30.044, 31.236),
        City("الإسكندرية", "مصر", 31.200, 29.919),
        City("الرياض", "السعودية", 24.714, 46.675),
        City("جدة", "السعودية", 21.543, 39.173),
        City("دبي", "الإمارات", 25.205, 55.271),
        City("بغداد", "العراق", 33.315, 44.366),
        City("عمّان", "الأردن", 31.954, 35.910),
        City("بيروت", "لبنان", 33.894, 35.502),
        City("الدار البيضاء", "المغرب", 33.573, -7.590),
        City("تونس", "تونس", 36.806, 10.182),
        City("الجزائر", "الجزائر", 36.753, 3.059),
        City("إسطنبول", "تركيا", 41.009, 28.978),
        City("لندن", "بريطانيا", 51.507, -0.128),
        City("باريس", "فرنسا", 48.857, 2.352),
        City("نيويورك", "أمريكا", 40.713, -74.006),
        City("لوس أنجلوس", "أمريكا", 34.052, -118.244),
        City("ميامي", "أمريكا", 25.762, -80.192),
        City("هيوستن", "أمريكا", 29.760, -95.370),
        City("نيو أورلينز", "أمريكا", 29.951, -90.072),
        City("أوكلاهوما سيتي", "أمريكا", 35.468, -97.516),
        City("طوكيو", "اليابان", 35.682, 139.759),
        City("مانيلا", "الفلبين", 14.600, 120.984),
        City("جاكرتا", "إندونيسيا", -6.209, 106.846),
        City("مدينة مكسيكو", "المكسيك", 19.433, -99.133)
    )
}
