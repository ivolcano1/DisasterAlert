package com.example.disasteralert

import org.json.JSONObject
import java.net.URLEncoder
import java.util.Calendar
import java.util.Locale

data class NowW(
    val temp: Double, val feels: Double, val humidity: Int, val wind: Double,
    val pressure: Double, val code: Int, val isDay: Boolean
)

data class DayW(val date: String, val tMax: Double, val tMin: Double, val code: Int, val rain: Double)

data class WeatherData(
    val now: NowW,
    val hourTemps: List<Double>,   // 24 قيمة تبدأ من الساعة الحالية
    val startHour: Int,
    val days: List<DayW>
)

object Wx {
    fun desc(code: Int): String = when (code) {
        0 -> L.t("صافٍ", "Clear")
        1 -> L.t("صافٍ غالباً", "Mostly clear")
        2 -> L.t("غائم جزئياً", "Partly cloudy")
        3 -> L.t("غائم", "Overcast")
        45, 48 -> L.t("ضباب", "Fog")
        in 51..57 -> L.t("رذاذ", "Drizzle")
        in 61..67 -> L.t("مطر", "Rain")
        in 71..77 -> L.t("ثلوج", "Snow")
        in 80..82 -> L.t("زخات مطر", "Rain showers")
        85, 86 -> L.t("زخات ثلج", "Snow showers")
        95 -> L.t("عاصفة رعدية", "Thunderstorm")
        96, 99 -> L.t("عاصفة رعدية وبَرَد", "Thunderstorm with hail")
        else -> "—"
    }

    fun icon(code: Int, day: Boolean): Int = when (code) {
        0, 1 -> if (day) R.drawable.ic_w_sun else R.drawable.ic_w_moon
        2 -> R.drawable.ic_w_partly
        3 -> R.drawable.ic_w_cloud
        45, 48 -> R.drawable.ic_w_fog
        in 51..67, in 80..82 -> R.drawable.ic_w_rain
        in 71..77, 85, 86 -> R.drawable.ic_w_snow
        95, 96, 99 -> R.drawable.ic_h_storm
        else -> R.drawable.ic_w_cloud
    }

    fun color(code: Int): Int = when (code) {
        0, 1 -> android.graphics.Color.parseColor("#FFC857")
        2 -> android.graphics.Color.parseColor("#FFD98A")
        in 51..67, in 80..82 -> Ui.ACCENT
        in 71..77, 85, 86 -> android.graphics.Color.parseColor("#CFE8FF")
        95, 96, 99 -> Ui.VIOLET
        else -> Ui.DIM
    }
}

object Weather {
    private fun f(x: Double) = String.format(Locale.US, "%.3f", x)

    fun fetch(lat: Double, lon: Double): WeatherData {
        val url = "https://api.open-meteo.com/v1/forecast?latitude=${f(lat)}&longitude=${f(lon)}" +
            "&current=temperature_2m,apparent_temperature,relative_humidity_2m,weather_code,wind_speed_10m,surface_pressure,is_day" +
            "&hourly=temperature_2m" +
            "&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_sum" +
            "&forecast_days=7&timezone=auto&wind_speed_unit=kmh"
        val j = JSONObject(Net.get(url))
        val cu = j.getJSONObject("current")
        val hour = cu.getString("time").substring(11, 13).toInt()
        val now = NowW(
            cu.getDouble("temperature_2m"),
            cu.optDouble("apparent_temperature", cu.getDouble("temperature_2m")),
            cu.optInt("relative_humidity_2m", 0),
            cu.optDouble("wind_speed_10m", 0.0),
            cu.optDouble("surface_pressure", 0.0),
            cu.optInt("weather_code", 0),
            cu.optInt("is_day", 1) == 1
        )
        val ht = j.getJSONObject("hourly").getJSONArray("temperature_2m")
        val temps = mutableListOf<Double>()
        for (k in 0 until 24) {
            val v = ht.optDouble(hour + k, Double.NaN)
            temps += if (v.isNaN()) now.temp else v
        }
        val d = j.getJSONObject("daily")
        val dates = d.getJSONArray("time")
        val days = mutableListOf<DayW>()
        for (i in 0 until dates.length()) {
            days += DayW(
                dates.getString(i),
                d.getJSONArray("temperature_2m_max").optDouble(i, 0.0),
                d.getJSONArray("temperature_2m_min").optDouble(i, 0.0),
                d.getJSONArray("weather_code").optInt(i, 0),
                d.getJSONArray("precipitation_sum").optDouble(i, 0.0)
            )
        }
        return WeatherData(now, temps, hour, days)
    }

    private val weekdaysAr = arrayOf("الأحد", "الإثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت")
    private val weekdaysEn = arrayOf("Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday")

    fun dayName(date: String, index: Int): String {
        if (index == 0) return L.t("اليوم", "Today")
        if (index == 1) return L.t("غداً", "Tomorrow")
        return try {
            val p = date.split("-")
            val c = Calendar.getInstance()
            c.set(p[0].toInt(), p[1].toInt() - 1, p[2].toInt())
            val i = c.get(Calendar.DAY_OF_WEEK) - 1
            if (L.ar) weekdaysAr[i] else weekdaysEn[i]
        } catch (e: Exception) {
            date
        }
    }
}

object Geo {
    /** بحث عن مدينة بالاسم (Open-Meteo Geocoding، مجاني بدون مفتاح). */
    fun search(q: String): List<City> {
        val url = "https://geocoding-api.open-meteo.com/v1/search?name=" +
            URLEncoder.encode(q.trim(), "UTF-8") + "&count=8&language=" + (if (L.ar) "ar" else "en") + "&format=json"
        val arr = JSONObject(Net.get(url)).optJSONArray("results") ?: return emptyList()
        val out = mutableListOf<City>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val region = listOf(o.optString("admin1"), o.optString("country"))
                .filter { it.isNotBlank() }.joinToString("، ")
            out += City(o.getString("name"), region, o.getDouble("latitude"), o.getDouble("longitude"), false, o.optString("country_code"))
        }
        return out
    }
}
