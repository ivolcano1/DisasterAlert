package com.example.disasteralert

import android.os.Build
import android.view.View
import android.view.WindowInsets

/** أندرويد 15+ يفرض العرض بملء الشاشة؛ نضيف حشوة بحجم أشرطة النظام حتى لا يتداخل المحتوى معها. */
object Edge {
    @Suppress("DEPRECATION")
    fun apply(v: View) {
        v.setOnApplyWindowInsetsListener { view, ins ->
            if (Build.VERSION.SDK_INT >= 30) {
                val b = ins.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
                view.setPadding(b.left, b.top, b.right, b.bottom)
            } else {
                view.setPadding(
                    ins.systemWindowInsetLeft, ins.systemWindowInsetTop,
                    ins.systemWindowInsetRight, ins.systemWindowInsetBottom
                )
            }
            ins
        }
    }
}
