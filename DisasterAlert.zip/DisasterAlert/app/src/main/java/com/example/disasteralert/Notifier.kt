package com.example.disasteralert

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat

object Notifier {
    private const val CHANNEL = "disaster_alerts"
    private const val PREFS = "prefs"

    fun ensureChannel(ctx: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(CHANNEL, L.t("تنبيهات الكوارث", "Disaster alerts"), NotificationManager.IMPORTANCE_HIGH)
            ch.description = L.t("تنبيهات الزلازل والفيضانات والبراكين والعواصف والطقس القاسي", "Earthquake, flood, volcano, storm and extreme weather alerts")
            ctx.getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
    }

    /** يرسل فقط التنبيهات التي لم تُرسل من قبل لهذه المدينة. */
    @Synchronized
    fun notifyNew(ctx: Context, city: City, alerts: List<Alert>) {
        L.init(ctx)
        ensureChannel(ctx)
        val prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val seen = (prefs.getStringSet("seen", emptySet()) ?: emptySet()).toMutableSet()
        val canPost = Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        for (a in alerts) {
            val key = city.key + "|" + a.id
            if (key in seen) continue
            if (a.forecast && !Store.forecastNotifs(ctx)) continue
            seen += key
            if (!canPost) continue
            val pi = PendingIntent.getActivity(
                ctx, 0, Intent(ctx, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val n = NotificationCompat.Builder(ctx, CHANNEL)
                .setSmallIcon(R.drawable.ic_notification)
                .setContentTitle("⚠️ ${city.name}: ${a.title}")
                .setContentText(a.body)
                .setStyle(NotificationCompat.BigTextStyle().bigText(a.body))
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setContentIntent(pi)
                .setAutoCancel(true)
                .build()
            try {
                NotificationManagerCompat.from(ctx).notify(key.hashCode(), n)
            } catch (_: SecurityException) {
            }
        }
        prefs.edit().putStringSet("seen", seen.toList().takeLast(500).toSet()).apply()
    }
}
