package com.example.disasteralert

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.asin
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/** forecast = true يعني «توقع/إنذار مبكر مبني على اتجاه»، وليس حدثاً وقع فعلاً. */
data class Alert(val id: String, val title: String, val body: String, val forecast: Boolean = false)

/** failed = أسماء المصادر التي تعذّر الوصول إليها، حتى لا نُظهر «كل شيء آمن» عند فشل الاتصال. */
data class Report(val alerts: List<Alert>, val failed: List<String>)

object Checker {

    private const val SOURCES = 4

    private fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 25000
        c.setRequestProperty("User-Agent", "DisasterAlertApp/1.0")
        return try {
            if (c.responseCode !in 200..299) throw java.io.IOException("HTTP ${c.responseCode}")
            c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    private fun km(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val r = 6371.0
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = sin(dLat / 2).pow(2) +
            cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) * sin(dLon / 2).pow(2)
        return 2 * r * asin(sqrt(a))
    }

    private fun c(x: Double) = String.format(Locale.US, "%.3f", x)
    private fun fmt(cal: Calendar) = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.time)
    private fun today() = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

    fun sourceCount() = SOURCES

    fun check(ctx: Context, lat: Double, lon: Double): Report {
        val out = mutableListOf<Alert>()
        val failed = mutableListOf<String>()
        fun collect(name: String, f: () -> List<Alert>) {
            try {
                out += f()
            } catch (e: Exception) {
                failed += name
            }
        }
        collect("الزلازل") { earthquakes(lat, lon) }
        collect("الطقس والتوقعات") { weather(ctx, lat, lon) }
        collect("الفيضانات") { flood(lat, lon) }
        collect("البراكين والعواصف") { eonet(lat, lon) }
        return Report(out, failed)
    }

    // ================= الزلازل (USGS) =================
    // ملاحظة علمية: لا يمكن التنبؤ بموعد الزلزال. نرصد (1) الزلازل الحالية، (2) خطر الهزات
    // الارتدادية بعد زلزال كبير، (3) تجمّع هزات صغيرة غير معتاد (swarm) كإشارة لرفع الحذر فقط.
    private fun earthquakes(lat: Double, lon: Double): List<Alert> {
        val now = System.currentTimeMillis()
        val res = mutableListOf<Alert>()

        val week = JSONObject(get("https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/4.5_week.geojson"))
            .getJSONArray("features")
        for (i in 0 until week.length()) {
            val f = week.getJSONObject(i)
            val p = f.getJSONObject("properties")
            val mag = p.optDouble("mag", 0.0)
            val ageH = (now - p.optLong("time", 0)) / 3600000.0
            val co = f.getJSONObject("geometry").getJSONArray("coordinates")
            val d = km(lat, lon, co.getDouble(1), co.getDouble(0))
            val id = f.getString("id")
            if (ageH <= 24 && ((mag >= 4.5 && d <= 500) || (mag >= 6.5 && d <= 3000))) {
                res += Alert("eq-$id", "زلزال بقوة " + String.format(Locale.US, "%.1f", mag),
                    "${p.optString("place")} — يبعد عنك حوالي ${d.toInt()} كم")
            }
            if (ageH <= 168 && mag >= 5.5 && d <= 300) {
                res += Alert("eqw-$id", "توقع: احتمال هزات ارتدادية",
                    "وقع زلزال بقوة ${String.format(Locale.US, "%.1f", mag)} على بعد ${d.toInt()} كم. " +
                        "قد تحدث هزات ارتدادية خلال الأيام القادمة وقد تكون أحياناً أقوى. ابتعد عن المباني المتضررة.",
                    true)
            }
        }

        val day = JSONObject(get("https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/2.5_day.geojson"))
            .getJSONArray("features")
        var cnt = 0
        for (i in 0 until day.length()) {
            val co = day.getJSONObject(i).getJSONObject("geometry").getJSONArray("coordinates")
            if (km(lat, lon, co.getDouble(1), co.getDouble(0)) <= 100) cnt++
        }
        if (cnt >= 10) {
            res += Alert("swarm-${today()}", "توقع: نشاط زلزالي غير معتاد",
                "سُجّلت $cnt هزة (2.5+) خلال 24 ساعة ضمن 100 كم منك. هذا لا يعني حتماً زلزالاً كبيراً، لكن يُنصح برفع الحذر ومراجعة خطة الطوارئ.",
                true)
        }
        return res
    }

    // ================= الطقس والمناخ (Open-Meteo) =================
    private fun weather(ctx: Context, lat: Double, lon: Double): List<Alert> {
        val url = "https://api.open-meteo.com/v1/forecast?latitude=${c(lat)}&longitude=${c(lon)}" +
            "&daily=temperature_2m_max,temperature_2m_min,precipitation_sum,wind_gusts_10m_max,weather_code" +
            "&hourly=surface_pressure,precipitation" +
            "&past_days=3&forecast_days=7&timezone=auto&wind_speed_unit=kmh"
        val j = JSONObject(get(url))
        val d = j.getJSONObject("daily")
        val h = j.getJSONObject("hourly")
        val dates = d.getJSONArray("time")
        val n = dates.length()
        val t0 = n - 7 // فهرس اليوم الحالي (قبله 3 أيام ماضية)
        fun dv(key: String, i: Int) = d.getJSONArray(key).optDouble(i, Double.NaN)

        val res = mutableListOf<Alert>()

        // ---- أحداث اليوم وغداً ----
        for (i in t0..minOf(t0 + 1, n - 1)) {
            val day = dates.getString(i)
            val tMax = dv("temperature_2m_max", i)
            val tMin = dv("temperature_2m_min", i)
            val rain = dv("precipitation_sum", i)
            val gust = dv("wind_gusts_10m_max", i)
            val code = d.getJSONArray("weather_code").optInt(i, 0)
            if (tMax >= 42) res += Alert("heat-$day", "موجة حر شديد",
                "الحرارة العظمى المتوقعة ${tMax.toInt()}°م بتاريخ $day. تجنّب الشمس واشرب الماء.")
            if (tMin <= -5) res += Alert("cold-$day", "موجة برد قارس",
                "الحرارة الصغرى المتوقعة ${tMin.toInt()}°م بتاريخ $day. احرص على التدفئة.")
            if (gust >= 75 || code in 95..99) res += Alert("storm-$day", "عاصفة قوية",
                "هبّات رياح حتى ${gust.toInt()} كم/س" + (if (code in 95..99) " مع عواصف رعدية" else "") + " بتاريخ $day.")
            if (rain >= 50) res += Alert("rain-$day", "أمطار غزيرة",
                "هطول متوقع ${rain.toInt()} مم بتاريخ $day. احذر من السيول.")
        }

        // ---- اتجاهات الأيام القادمة ----
        var heatRun = 0; var maxHeatRun = 0
        var coldRun = 0; var maxColdRun = 0
        var sumMax = 0.0; var cntMax = 0
        for (i in t0 until n) {
            val tMax = dv("temperature_2m_max", i)
            val tMin = dv("temperature_2m_min", i)
            heatRun = if (tMax >= 40) heatRun + 1 else 0
            coldRun = if (tMin <= -3) coldRun + 1 else 0
            if (heatRun > maxHeatRun) maxHeatRun = heatRun
            if (coldRun > maxColdRun) maxColdRun = coldRun
            if (!tMax.isNaN()) { sumMax += tMax; cntMax++ }
        }
        val today = today()
        if (maxHeatRun >= 3) res += Alert("fc-heat-$today", "توقع: موجة حر ممتدة",
            "يُتوقع أن تبلغ الحرارة 40°م فأكثر لمدة $maxHeatRun أيام متتالية خلال الأسبوع القادم. جهّز الماء وقلّل التعرض للشمس.", true)
        if (maxColdRun >= 2) res += Alert("fc-cold-$today", "توقع: موجة برد ممتدة",
            "يُتوقع انخفاض الحرارة إلى -3°م أو أقل لمدة $maxColdRun أيام متتالية. جهّز التدفئة والملابس الثقيلة.", true)

        // شذوذ مناخي: توقعات الأسبوع القادم مقابل متوسط نفس الأيام في آخر 3 سنوات
        val base = runCatching { baseline(ctx, lat, lon) }.getOrDefault(Double.NaN)
        if (!base.isNaN() && cntMax >= 5) {
            val diff = sumMax / cntMax - base
            if (diff >= 7) res += Alert("fc-anom-hot-$today", "توقع: ارتفاع حراري غير معتاد",
                "متوسط الحرارة العظمى المتوقع للأسبوع القادم أعلى من المعتاد لهذا الوقت بحوالي ${diff.toInt()}°م.", true)
            if (diff <= -7) res += Alert("fc-anom-cold-$today", "توقع: انخفاض حراري غير معتاد",
                "متوسط الحرارة العظمى المتوقع للأسبوع القادم أقل من المعتاد لهذا الوقت بحوالي ${(-diff).toInt()}°م.", true)
        }

        // ---- اتجاهات الضغط والأمطار (بالساعة) ----
        val hp = h.getJSONArray("surface_pressure")
        val hr = h.getJSONArray("precipitation")
        val offset = j.optLong("utc_offset_seconds", 0)
        val hourNow = Math.floorMod((System.currentTimeMillis() / 1000 + offset) / 3600, 24L).toInt()
        val now = t0 * 24 + hourNow
        if (now + 24 < hp.length() && now - 72 >= 0) {
            val p0 = hp.optDouble(now, Double.NaN)
            val p24 = hp.optDouble(now + 24, Double.NaN)
            if (p24 - p0 <= -12) res += Alert("fc-press-$today", "توقع: هبوط حاد في الضغط الجوي",
                "يُتوقع هبوط الضغط بحوالي ${(p0 - p24).toInt()} هكتوباسكال خلال 24 ساعة، وهو مؤشر على اقتراب عاصفة قوية.", true)

            var sum24 = 0.0; var maxH = 0.0
            for (k in now until now + 24) {
                val v = hr.optDouble(k, 0.0)
                sum24 += v
                if (v > maxH) maxH = v
            }
            if (sum24 >= 60 || maxH >= 25) res += Alert("fc-flash-$today", "توقع: خطر سيول مفاجئة",
                "يُتوقع هطول ${sum24.toInt()} مم خلال 24 ساعة (ذروة ${maxH.toInt()} مم/ساعة). ابتعد عن الأودية ومجاري السيول.", true)

            var win = 0.0
            for (k in now - 72 until minOf(now + 48, hr.length())) win += hr.optDouble(k, 0.0)
            if (win >= 150) res += Alert("fc-sat-$today", "توقع: تشبّع التربة وخطر فيضان",
                "تراكم الأمطار الماضية والمتوقعة خلال 5 أيام يبلغ ${win.toInt()} مم، فيزداد خطر الفيضانات والانهيارات.", true)
        }
        return res
    }

    /** متوسط الحرارة العظمى لنفس الأيام السبعة القادمة في آخر 3 سنوات (يُخزَّن يوماً كاملاً). */
    private fun baseline(ctx: Context, lat: Double, lon: Double): Double {
        val prefs = ctx.getSharedPreferences("prefs", Context.MODE_PRIVATE)
        val key = "${today()}|${String.format(Locale.US, "%.1f", lat)}|${String.format(Locale.US, "%.1f", lon)}"
        if (prefs.getString("bkey", "") == key) return prefs.getFloat("bval", Float.NaN).toDouble()
        var sum = 0.0
        var cnt = 0
        for (y in 1..3) {
            val c1 = Calendar.getInstance()
            c1.add(Calendar.YEAR, -y)
            val c2 = c1.clone() as Calendar
            c2.add(Calendar.DAY_OF_YEAR, 6)
            val url = "https://archive-api.open-meteo.com/v1/archive?latitude=${c(lat)}&longitude=${c(lon)}" +
                "&start_date=${fmt(c1)}&end_date=${fmt(c2)}&daily=temperature_2m_max&timezone=auto"
            val arr = JSONObject(get(url)).getJSONObject("daily").getJSONArray("temperature_2m_max")
            for (i in 0 until arr.length()) if (!arr.isNull(i)) { sum += arr.getDouble(i); cnt++ }
        }
        val v = if (cnt >= 10) sum / cnt else Double.NaN
        prefs.edit().putString("bkey", key).putFloat("bval", v.toFloat()).apply()
        return v
    }

    // ================= الفيضانات (Open-Meteo Flood) =================
    private fun flood(lat: Double, lon: Double): List<Alert> {
        val url = "https://flood-api.open-meteo.com/v1/flood?latitude=${c(lat)}&longitude=${c(lon)}" +
            "&daily=river_discharge,river_discharge_mean&forecast_days=5"
        val d = JSONObject(get(url)).getJSONObject("daily")
        val dates = d.getJSONArray("time")
        val q = d.getJSONArray("river_discharge")
        val m = d.getJSONArray("river_discharge_mean")
        for (i in 0 until dates.length()) {
            if (q.isNull(i) || m.isNull(i)) continue
            val cur = q.getDouble(i)
            val mean = m.getDouble(i)
            if (mean > 0 && cur / mean >= 3.0) {
                return listOf(Alert("flood-${dates.getString(i)}", "توقع: خطر فيضان",
                    "تدفق النهر القريب متوقع أن يبلغ " + String.format(Locale.US, "%.1f", cur / mean) +
                        " ضعف المعدل الطبيعي بتاريخ ${dates.getString(i)}.", true))
            }
        }
        return emptyList()
    }

    // ================= براكين وعواصف (NASA EONET — مبنية على رصد الأقمار الصناعية) =================
    private fun eonet(lat: Double, lon: Double): List<Alert> {
        val json = JSONObject(get("https://eonet.gsfc.nasa.gov/api/v3/events?status=open&days=10&category=volcanoes,severeStorms"))
        val events = json.getJSONArray("events")
        val res = mutableListOf<Alert>()
        for (i in 0 until events.length()) {
            val e = events.getJSONObject(i)
            val cat = e.getJSONArray("categories").getJSONObject(0).getString("id")
            val geoms = e.getJSONArray("geometry")
            if (geoms.length() == 0) continue
            val g = geoms.getJSONObject(geoms.length() - 1)
            if (g.optString("type") != "Point") continue
            val co = g.getJSONArray("coordinates")
            val d = km(lat, lon, co.getDouble(1), co.getDouble(0))
            val isVolcano = cat == "volcanoes"
            if (d <= (if (isVolcano) 300 else 600)) {
                res += Alert("eonet-" + e.getString("id"),
                    if (isVolcano) "نشاط بركاني قريب" else "عاصفة شديدة قريبة",
                    "${e.getString("title")} — يبعد حوالي ${d.toInt()} كم عنك.")
            }
        }
        return res
    }
}
