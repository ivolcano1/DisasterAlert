package com.example.disasteralert

import android.content.Context
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.asin
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * يجمع التنبيهات لمدينة واحدة من مصادر مجانية:
 * USGS (زلازل) • Open-Meteo (طقس/مناخ/فيضانات) • NASA EONET (براكين وعواصف من الأقمار)
 * • NWS (تحذيرات رسمية داخل أمريكا) • GDACS (أعاصير مدارية وفيضانات وبراكين عالمياً)
 */
object Checker {

    private fun km(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val r = 6371.0
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = sin(dLat / 2).pow(2) +
            cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) * sin(dLon / 2).pow(2)
        return 2 * r * asin(sqrt(a))
    }

    private fun c(x: Double) = String.format(Locale.US, "%.3f", x)
    private fun d1(x: Double) = String.format(Locale.US, "%.1f", x)
    private fun fmt(cal: Calendar) = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.time)
    private fun today() = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

    private fun isUS(lat: Double, lon: Double) =
        (lat in 24.0..49.5 && lon in -125.0..-66.5) ||   // الولايات المتحدة القارية
            (lat in 51.0..72.0 && lon in -170.0..-129.0) || // ألاسكا
            (lat in 18.5..22.5 && lon in -161.0..-154.0) || // هاواي
            (lat in 17.5..18.6 && lon in -68.0..-65.0)       // بورتوريكو

    fun check(ctx: Context, city: City): Report {
        val lat = city.lat
        val lon = city.lon
        val out = mutableListOf<Alert>()
        val failed = mutableListOf<String>()
        var attempted = 0
        fun collect(name: String, optional: Boolean = false, f: () -> List<Alert>) {
            if (!optional) attempted++
            try {
                out += f()
            } catch (e: Exception) {
                if (!optional) failed += name
            }
        }
        collect("الزلازل") { earthquakes(lat, lon) }
        collect("الطقس والتوقعات") { weather(ctx, city) }
        collect("الفيضانات") { flood(lat, lon) }
        collect("البراكين والعواصف") { eonet(lat, lon) }
        if (isUS(lat, lon)) collect("تحذيرات الأرصاد الأمريكية") { nws(lat, lon) }
        collect("GDACS", optional = true) { gdacs(lat, lon) }
        return Report(city, out, failed, attempted)
    }

    // ================= الزلازل (USGS) =================
    // لا يمكن التنبؤ بموعد الزلزال. نرصد: الزلازل الحالية، خطر الهزات الارتدادية، وتجمّع الهزات.
    private fun earthquakes(lat: Double, lon: Double): List<Alert> {
        val now = System.currentTimeMillis()
        val res = mutableListOf<Alert>()
        val ttl = 5 * 60 * 1000L

        val week = JSONObject(Net.getCached("https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/4.5_week.geojson", ttl))
            .getJSONArray("features")
        for (i in 0 until week.length()) {
            val f = week.getJSONObject(i)
            val p = f.getJSONObject("properties")
            val mag = p.optDouble("mag", 0.0)
            val ageH = (now - p.optLong("time", 0)) / 3600000.0
            val co = f.getJSONObject("geometry").getJSONArray("coordinates")
            val d = km(lat, lon, co.getDouble(1), co.getDouble(0))
            val id = f.getString("id")
            if (ageH <= 24 && ((mag >= 4.5 && d <= 500) || (mag >= 6.5 && d <= 3000))) {
                res += Alert("eq-$id", Hazard.QUAKE, "زلزال بقوة " + d1(mag),
                    "${p.optString("place")} — يبعد عنك حوالي ${d.toInt()} كم")
            }
            if (ageH <= 168 && mag >= 5.5 && d <= 300) {
                res += Alert("eqw-$id", Hazard.QUAKE, "توقع: احتمال هزات ارتدادية",
                    "وقع زلزال بقوة ${d1(mag)} على بعد ${d.toInt()} كم. قد تحدث هزات ارتدادية خلال الأيام القادمة وقد تكون أحياناً أقوى. ابتعد عن المباني المتضررة.",
                    forecast = true)
            }
        }

        val day = JSONObject(Net.getCached("https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/2.5_day.geojson", ttl))
            .getJSONArray("features")
        var cnt = 0
        for (i in 0 until day.length()) {
            val co = day.getJSONObject(i).getJSONObject("geometry").getJSONArray("coordinates")
            if (km(lat, lon, co.getDouble(1), co.getDouble(0)) <= 100) cnt++
        }
        if (cnt >= 10) {
            res += Alert("swarm-${today()}", Hazard.QUAKE, "توقع: نشاط زلزالي غير معتاد",
                "سُجّلت $cnt هزة (2.5+) خلال 24 ساعة ضمن 100 كم. هذا لا يعني حتماً زلزالاً كبيراً، لكن يُنصح برفع الحذر ومراجعة خطة الطوارئ.",
                forecast = true)
        }
        return res
    }

    // ================= الطقس والمناخ (Open-Meteo) =================
    private fun weather(ctx: Context, city: City): List<Alert> {
        val lat = city.lat
        val lon = city.lon
        val url = "https://api.open-meteo.com/v1/forecast?latitude=${c(lat)}&longitude=${c(lon)}" +
            "&daily=temperature_2m_max,temperature_2m_min,precipitation_sum,wind_gusts_10m_max,weather_code" +
            "&hourly=surface_pressure,precipitation" +
            "&past_days=3&forecast_days=7&timezone=auto&wind_speed_unit=kmh"
        val j = JSONObject(Net.get(url))
        val d = j.getJSONObject("daily")
        val h = j.getJSONObject("hourly")
        val dates = d.getJSONArray("time")
        val n = dates.length()
        val t0 = n - 7
        fun dv(key: String, i: Int) = d.getJSONArray(key).optDouble(i, Double.NaN)

        val res = mutableListOf<Alert>()

        for (i in t0..minOf(t0 + 1, n - 1)) {
            val day = dates.getString(i)
            val tMax = dv("temperature_2m_max", i)
            val tMin = dv("temperature_2m_min", i)
            val rain = dv("precipitation_sum", i)
            val gust = dv("wind_gusts_10m_max", i)
            val code = d.getJSONArray("weather_code").optInt(i, 0)
            if (tMax >= 42) res += Alert("heat-$day", Hazard.HEAT, "موجة حر شديد",
                "الحرارة العظمى المتوقعة ${tMax.toInt()}°م بتاريخ $day. تجنّب الشمس واشرب الماء.")
            if (tMin <= -5) res += Alert("cold-$day", Hazard.COLD, "موجة برد قارس",
                "الحرارة الصغرى المتوقعة ${tMin.toInt()}°م بتاريخ $day. احرص على التدفئة.")
            if (gust >= 75 || code in 95..99) res += Alert("storm-$day", Hazard.STORM, "عاصفة قوية",
                "هبّات رياح حتى ${gust.toInt()} كم/س" + (if (code in 95..99) " مع عواصف رعدية" else "") + " بتاريخ $day.")
            if (rain >= 50) res += Alert("rain-$day", Hazard.FLOOD, "أمطار غزيرة",
                "هطول متوقع ${rain.toInt()} مم بتاريخ $day. احذر من السيول.")
        }

        var heatRun = 0; var maxHeatRun = 0
        var coldRun = 0; var maxColdRun = 0
        var sumMax = 0.0; var cntMax = 0
        for (i in t0 until n) {
            val tMax = dv("temperature_2m_max", i)
            val tMin = dv("temperature_2m_min", i)
            heatRun = if (tMax >= 40) heatRun + 1 else 0
            coldRun = if (tMin <= -3) coldRun + 1 else 0
            if (heatRun > maxHeatRun) maxHeatRun = heatRun
            if (coldRun > maxColdRun) maxColdRun = coldRun
            if (!tMax.isNaN()) { sumMax += tMax; cntMax++ }
        }
        val td = today()
        if (maxHeatRun >= 3) res += Alert("fc-heat-$td", Hazard.HEAT, "توقع: موجة حر ممتدة",
            "يُتوقع أن تبلغ الحرارة 40°م فأكثر لمدة $maxHeatRun أيام متتالية. جهّز الماء وقلّل التعرض للشمس.", forecast = true)
        if (maxColdRun >= 2) res += Alert("fc-cold-$td", Hazard.COLD, "توقع: موجة برد ممتدة",
            "يُتوقع انخفاض الحرارة إلى -3°م أو أقل لمدة $maxColdRun أيام متتالية. جهّز التدفئة والملابس الثقيلة.", forecast = true)

        val base = runCatching { baseline(ctx, city) }.getOrDefault(Double.NaN)
        if (!base.isNaN() && cntMax >= 5) {
            val diff = sumMax / cntMax - base
            if (diff >= 7) res += Alert("fc-anom-hot-$td", Hazard.HEAT, "توقع: ارتفاع حراري غير معتاد",
                "متوسط الحرارة العظمى المتوقع للأسبوع القادم أعلى من المعتاد لهذا الوقت بحوالي ${diff.toInt()}°م.", forecast = true)
            if (diff <= -7) res += Alert("fc-anom-cold-$td", Hazard.COLD, "توقع: انخفاض حراري غير معتاد",
                "متوسط الحرارة العظمى المتوقع للأسبوع القادم أقل من المعتاد لهذا الوقت بحوالي ${(-diff).toInt()}°م.", forecast = true)
        }

        val hp = h.getJSONArray("surface_pressure")
        val hr = h.getJSONArray("precipitation")
        val offset = j.optLong("utc_offset_seconds", 0)
        val hourNow = Math.floorMod((System.currentTimeMillis() / 1000 + offset) / 3600, 24L).toInt()
        val now = t0 * 24 + hourNow
        if (now + 24 < hp.length() && now - 72 >= 0) {
            val p0 = hp.optDouble(now, Double.NaN)
            val p24 = hp.optDouble(now + 24, Double.NaN)
            if (p24 - p0 <= -12) res += Alert("fc-press-$td", Hazard.STORM, "توقع: هبوط حاد في الضغط الجوي",
                "يُتوقع هبوط الضغط بحوالي ${(p0 - p24).toInt()} هكتوباسكال خلال 24 ساعة، وهو مؤشر على اقتراب عاصفة قوية.", forecast = true)

            var sum24 = 0.0; var maxH = 0.0
            for (k in now until now + 24) {
                val v = hr.optDouble(k, 0.0)
                sum24 += v
                if (v > maxH) maxH = v
            }
            if (sum24 >= 60 || maxH >= 25) res += Alert("fc-flash-$td", Hazard.FLOOD, "توقع: خطر سيول مفاجئة",
                "يُتوقع هطول ${sum24.toInt()} مم خلال 24 ساعة (ذروة ${maxH.toInt()} مم/ساعة). ابتعد عن الأودية ومجاري السيول.", forecast = true)

            var win = 0.0
            for (k in now - 72 until minOf(now + 48, hr.length())) win += hr.optDouble(k, 0.0)
            if (win >= 150) res += Alert("fc-sat-$td", Hazard.FLOOD, "توقع: تشبّع التربة وخطر فيضان",
                "تراكم الأمطار الماضية والمتوقعة خلال 5 أيام يبلغ ${win.toInt()} مم، فيزداد خطر الفيضانات والانهيارات.", forecast = true)
        }
        return res
    }

    /** متوسط الحرارة العظمى لنفس الأيام السبعة القادمة في آخر 3 سنوات (يُخزَّن يوماً كاملاً لكل مدينة). */
    private fun baseline(ctx: Context, city: City): Double {
        val prefs = ctx.getSharedPreferences("prefs", Context.MODE_PRIVATE)
        val key = "b_" + city.key
        val stamp = today()
        val cached = prefs.getString(key, "") ?: ""
        if (cached.startsWith("$stamp;")) return cached.substringAfter(";").toDoubleOrNull() ?: Double.NaN
        var sum = 0.0
        var cnt = 0
        for (y in 1..3) {
            val c1 = Calendar.getInstance()
            c1.add(Calendar.YEAR, -y)
            val c2 = c1.clone() as Calendar
            c2.add(Calendar.DAY_OF_YEAR, 6)
            val url = "https://archive-api.open-meteo.com/v1/archive?latitude=${c(city.lat)}&longitude=${c(city.lon)}" +
                "&start_date=${fmt(c1)}&end_date=${fmt(c2)}&daily=temperature_2m_max&timezone=auto"
            val arr = JSONObject(Net.get(url)).getJSONObject("daily").getJSONArray("temperature_2m_max")
            for (i in 0 until arr.length()) if (!arr.isNull(i)) { sum += arr.getDouble(i); cnt++ }
        }
        val v = if (cnt >= 10) sum / cnt else Double.NaN
        prefs.edit().putString(key, "$stamp;$v").apply()
        return v
    }

    // ================= الفيضانات (Open-Meteo Flood) =================
    private fun flood(lat: Double, lon: Double): List<Alert> {
        val url = "https://flood-api.open-meteo.com/v1/flood?latitude=${c(lat)}&longitude=${c(lon)}" +
            "&daily=river_discharge,river_discharge_mean&forecast_days=5"
        val d = JSONObject(Net.get(url)).getJSONObject("daily")
        val dates = d.getJSONArray("time")
        val q = d.getJSONArray("river_discharge")
        val m = d.getJSONArray("river_discharge_mean")
        for (i in 0 until dates.length()) {
            if (q.isNull(i) || m.isNull(i)) continue
            val cur = q.getDouble(i)
            val mean = m.getDouble(i)
            if (mean > 0 && cur / mean >= 3.0) {
                return listOf(Alert("flood-${dates.getString(i)}", Hazard.FLOOD, "توقع: خطر فيضان",
                    "تدفق النهر القريب متوقع أن يبلغ ${d1(cur / mean)} ضعف المعدل الطبيعي بتاريخ ${dates.getString(i)}.",
                    forecast = true))
            }
        }
        return emptyList()
    }

    // ================= براكين وعواصف (NASA EONET — من رصد الأقمار الصناعية) =================
    private fun eonet(lat: Double, lon: Double): List<Alert> {
        val json = JSONObject(Net.getCached("https://eonet.gsfc.nasa.gov/api/v3/events?status=open&days=10&category=volcanoes,severeStorms", 10 * 60 * 1000L))
        val events = json.getJSONArray("events")
        val res = mutableListOf<Alert>()
        for (i in 0 until events.length()) {
            val e = events.getJSONObject(i)
            val cat = e.getJSONArray("categories").getJSONObject(0).getString("id")
            val geoms = e.getJSONArray("geometry")
            if (geoms.length() == 0) continue
            val g = geoms.getJSONObject(geoms.length() - 1)
            if (g.optString("type") != "Point") continue
            val co = g.getJSONArray("coordinates")
            val d = km(lat, lon, co.getDouble(1), co.getDouble(0))
            val isVolcano = cat == "volcanoes"
            if (d <= (if (isVolcano) 300 else 600)) {
                res += Alert("eonet-" + e.getString("id"),
                    if (isVolcano) Hazard.VOLCANO else Hazard.STORM,
                    if (isVolcano) "نشاط بركاني قريب" else "عاصفة شديدة قريبة",
                    "${e.getString("title")} — يبعد حوالي ${d.toInt()} كم عنك.")
            }
        }
        return res
    }

    // ================= تحذيرات رسمية داخل أمريكا (NWS) =================
    private data class NwsKind(val key: String, val hazard: Hazard, val ar: String)

    private val nwsKinds = listOf(
        NwsKind("Tornado", Hazard.STORM, "إعصار قمعي (تورنادو)"),
        NwsKind("Hurricane", Hazard.STORM, "إعصار"),
        NwsKind("Tropical Storm", Hazard.STORM, "عاصفة مدارية"),
        NwsKind("Typhoon", Hazard.STORM, "إعصار مداري"),
        NwsKind("Storm Surge", Hazard.FLOOD, "اندفاع مياه عاصفي"),
        NwsKind("Tsunami", Hazard.FLOOD, "تسونامي"),
        NwsKind("Thunderstorm", Hazard.STORM, "عواصف رعدية شديدة"),
        NwsKind("Blizzard", Hazard.COLD, "عاصفة ثلجية"),
        NwsKind("Ice Storm", Hazard.COLD, "عاصفة جليدية"),
        NwsKind("Winter Storm", Hazard.COLD, "عاصفة شتوية"),
        NwsKind("Winter Weather", Hazard.COLD, "طقس شتوي قاسٍ"),
        NwsKind("Wind Chill", Hazard.COLD, "برودة رياح قارسة"),
        NwsKind("Extreme Cold", Hazard.COLD, "برد شديد"),
        NwsKind("Freeze", Hazard.COLD, "صقيع"),
        NwsKind("Frost", Hazard.COLD, "صقيع"),
        NwsKind("Heat", Hazard.HEAT, "حرارة شديدة"),
        NwsKind("Flash Flood", Hazard.FLOOD, "سيول مفاجئة"),
        NwsKind("Flood", Hazard.FLOOD, "فيضان"),
        NwsKind("High Wind", Hazard.STORM, "رياح عاتية"),
        NwsKind("Wind", Hazard.STORM, "رياح قوية"),
        NwsKind("Red Flag", Hazard.HEAT, "خطر حرائق"),
        NwsKind("Fire", Hazard.HEAT, "خطر حرائق"),
        NwsKind("Earthquake", Hazard.QUAKE, "زلزال"),
        NwsKind("Volcano", Hazard.VOLCANO, "نشاط بركاني"),
        NwsKind("Dust", Hazard.STORM, "عاصفة غبار")
    )

    private fun nws(lat: Double, lon: Double): List<Alert> {
        val url = "https://api.weather.gov/alerts/active?point=" +
            String.format(Locale.US, "%.4f", lat) + "," + String.format(Locale.US, "%.4f", lon)
        val feats = JSONObject(Net.get(url, accept = "application/geo+json")).getJSONArray("features")
        val res = mutableListOf<Alert>()
        for (i in 0 until feats.length()) {
            val p = feats.getJSONObject(i).getJSONObject("properties")
            val sev = p.optString("severity")
            if (sev == "Minor" || sev == "Unknown") continue
            val event = p.optString("event")
            val kind = nwsKinds.firstOrNull { event.contains(it.key, ignoreCase = true) }
            val hz = kind?.hazard ?: Hazard.STORM
            val ar = kind?.ar ?: event
            val level = when {
                event.contains("Warning") -> "تحذير"
                event.contains("Watch") -> "ترقّب"
                event.contains("Advisory") -> "إشعار"
                else -> "تنبيه"
            }
            val soft = event.contains("Watch") || event.contains("Advisory") || event.contains("Outlook")
            res += Alert("nws-" + p.optString("id"), hz, "$ar — $level",
                p.optString("headline") + " (مصدر رسمي: هيئة الأرصاد الأمريكية NWS)",
                forecast = soft, official = true)
        }
        return res
    }

    // ================= GDACS: أعاصير مدارية وفيضانات وبراكين عالمياً (اختياري) =================
    private fun gdacs(lat: Double, lon: Double): List<Alert> {
        val feats = JSONObject(Net.getCached("https://www.gdacs.org/gdacsapi/api/events/geteventlist/EVENTS4APP", 10 * 60 * 1000L))
            .getJSONArray("features")
        val res = mutableListOf<Alert>()
        for (i in 0 until feats.length()) {
            val f = feats.getJSONObject(i)
            val p = f.optJSONObject("properties") ?: continue
            val level = p.optString("alertlevel")
            if (level.isBlank() || level.equals("Green", ignoreCase = true)) continue
            val type = p.optString("eventtype")
            val geom = f.optJSONObject("geometry") ?: continue
            if (geom.optString("type") != "Point") continue
            val co = geom.getJSONArray("coordinates")
            val d = km(lat, lon, co.getDouble(1), co.getDouble(0))
            val hz: Hazard
            val label: String
            val maxKm: Double
            when (type) {
                "TC" -> { hz = Hazard.STORM; label = "إعصار مداري / عاصفة مدارية"; maxKm = 900.0 }
                "FL" -> { hz = Hazard.FLOOD; label = "فيضان"; maxKm = 300.0 }
                "VO" -> { hz = Hazard.VOLCANO; label = "بركان"; maxKm = 300.0 }
                else -> continue
            }
            if (d > maxKm) continue
            val lv = if (level.equals("Red", ignoreCase = true)) "أحمر" else "برتقالي"
            res += Alert("gdacs-$type-" + p.optString("eventid"), hz, "$label — تنبيه $lv",
                p.optString("name") + " — يبعد حوالي ${d.toInt()} كم (مصدر: GDACS التابع للأمم المتحدة)",
                forecast = false, official = true)
        }
        return res
    }
}
