package com.example.disasteralert

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Shader
import android.graphics.SweepGradient
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

/** رادار متحرك: لون المركز يعكس الحالة، والنقاط الوامضة تمثل التنبيهات النشطة. */
class RadarView(ctx: Context) : View(ctx) {
    var tone: Int = Ui.OK
        set(v) { field = v; invalidate() }
    var blips: List<Int> = emptyList()
        set(v) { field = v; invalidate() }

    private var sweep = 0f
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = ctx.dp(1).toFloat()
        color = Ui.STROKE
    }
    private val sweepPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG)
    private val anim = ValueAnimator.ofFloat(0f, 360f).apply {
        duration = 3600
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            sweep = it.animatedValue as Float
            invalidate()
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        anim.start()
    }

    override fun onDetachedFromWindow() {
        anim.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = minOf(cx, cy) - context.dp(2)
        for (i in 1..3) c.drawCircle(cx, cy, r * i / 3f, ring)
        c.drawLine(cx - r, cy, cx + r, cy, ring)
        c.drawLine(cx, cy - r, cx, cy + r, ring)

        sweepPaint.shader = SweepGradient(
            cx, cy,
            intArrayOf(Color.TRANSPARENT, Color.TRANSPARENT, Ui.withAlpha(tone, 150)),
            floatArrayOf(0f, 0.7f, 1f)
        )
        c.save()
        c.rotate(sweep, cx, cy)
        c.drawCircle(cx, cy, r, sweepPaint)
        c.restore()

        for (a in blips) {
            val rad = Math.toRadians(a.toDouble())
            val dist = r * (0.35f + 0.55f * ((a * 7) % 10) / 10f)
            val x = cx + (dist * cos(rad)).toFloat()
            val y = cy + (dist * sin(rad)).toFloat()
            val diff = ((sweep - a) % 360f + 360f) % 360f
            val alpha = (255f - diff * 0.7f).coerceIn(70f, 255f).toInt()
            dot.color = Ui.withAlpha(tone, alpha)
            c.drawCircle(x, y, context.dp(3).toFloat(), dot)
        }
        dot.color = tone
        c.drawCircle(cx, cy, context.dp(4).toFloat(), dot)
    }
}

/** مخطط خطي ناعم لدرجات الحرارة خلال 24 ساعة (يتجه من اليمين لليسار في الواجهة العربية). */
class HourlyChart(ctx: Context) : View(ctx) {
    var temps: List<Double> = emptyList()
        set(v) { field = v; invalidate() }
    var startHour: Int = 0
        set(v) { field = v; invalidate() }

    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = ctx.dp(3).toFloat()
        color = Ui.ACCENT
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val dotP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Ui.ACCENT }
    private val dotIn = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Ui.SURFACE }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Ui.TEXT
        textSize = ctx.dp(12).toFloat()
        textAlign = Paint.Align.CENTER
    }
    private val dim = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Ui.DIM
        textSize = ctx.dp(11).toFloat()
        textAlign = Paint.Align.CENTER
    }

    override fun onDraw(c: Canvas) {
        val n = temps.size
        if (n < 2) return
        val w = width.toFloat()
        val h = height.toFloat()
        val padX = context.dp(14).toFloat()
        val top = context.dp(30).toFloat()
        val bottom = context.dp(24).toFloat()
        val mn = temps.minOrNull() ?: 0.0
        val mx = temps.maxOrNull() ?: 0.0
        val range = maxOf(mx - mn, 1.0)
        val rtl = layoutDirection == LAYOUT_DIRECTION_RTL

        fun x(i: Int): Float {
            val t = padX + (w - 2 * padX) * i / (n - 1)
            return if (rtl) w - t else t
        }
        fun y(v: Double): Float = (top + (h - top - bottom) * (1.0 - (v - mn) / range)).toFloat()

        val path = Path()
        path.moveTo(x(0), y(temps[0]))
        for (i in 1 until n) {
            val mx2 = (x(i - 1) + x(i)) / 2f
            path.cubicTo(mx2, y(temps[i - 1]), mx2, y(temps[i]), x(i), y(temps[i]))
        }
        val area = Path(path)
        area.lineTo(x(n - 1), h - bottom)
        area.lineTo(x(0), h - bottom)
        area.close()
        fill.shader = LinearGradient(0f, top, 0f, h - bottom, Ui.withAlpha(Ui.ACCENT, 90), Color.TRANSPARENT, Shader.TileMode.CLAMP)
        c.drawPath(area, fill)
        c.drawPath(path, line)

        for (i in 0 until n step 4) {
            val px = x(i)
            val py = y(temps[i])
            c.drawCircle(px, py, context.dp(5).toFloat(), dotP)
            c.drawCircle(px, py, context.dp(2).toFloat(), dotIn)
            c.drawText("${temps[i].roundToInt()}°", px, py - context.dp(10), txt)
            val hr = (startHour + i) % 24
            val label = if (i == 0) "الآن" else String.format(java.util.Locale.US, "%02d:00", hr)
            c.drawText(label, px, h - context.dp(6), dim)
        }
    }
}
