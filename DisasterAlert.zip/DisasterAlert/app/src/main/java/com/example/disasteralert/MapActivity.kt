package com.example.disasteralert

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient

/** خريطة بصور الأقمار الصناعية (NASA GIBS) للأمطار والسحب فوق موقعك. */
class MapActivity : Activity() {

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("prefs", Context.MODE_PRIVATE)
        val lat = java.lang.Double.longBitsToDouble(prefs.getLong("lat", java.lang.Double.doubleToLongBits(30.0)))
        val lon = java.lang.Double.longBitsToDouble(prefs.getLong("lon", java.lang.Double.doubleToLongBits(31.0)))

        val web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webViewClient = WebViewClient()
        setContentView(web)
        Edge.apply(web)
        web.loadUrl("file:///android_asset/map.html?lat=$lat&lon=$lon")
    }
}
