package com.example.disasteralert

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.animation.Animation
import android.view.animation.LinearInterpolator
import android.view.animation.RotateAnimation
import android.view.inputmethod.EditorInfo
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.core.widget.doAfterTextChanged
import kotlin.concurrent.thread
import kotlin.math.roundToInt

class MainActivity : Activity() {

    private lateinit var content: FrameLayout
    private val navItems = mutableListOf<LinearLayout>()
    private var tab = 0
    private var filter: Hazard? = null
    private var loading = false
    private var pendingRefresh = false
    private var lastRefresh = 0L
    private var wantGps = false
    private var web: WebView? = null
    private var webKey: String? = null
    private var searchResults: List<City> = emptyList()
    private var searchMsg: String? = null
    private var resultsBox: LinearLayout? = null
    private var query = ""
    private var detail: Pair<City?, Alert>? = null
    private var guideHazard: Hazard? = null
    private val offline = mutableSetOf<String>()

    private fun t(a: String, e: String) = L.t(a, e)

    // ======================= دورة الحياة =======================

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        L.init(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui.BG)
            layoutDirection = if (L.ar) View.LAYOUT_DIRECTION_RTL else View.LAYOUT_DIRECTION_LTR
        }
        content = FrameLayout(this)
        root.addView(content, lp(MATCH, 0, weight = 1f))
        root.addView(View(this).apply { setBackgroundColor(Ui.STROKE) }, lp(MATCH, dp(1)))
        root.addView(buildNav(), lp(MATCH, WRAP))
        setContentView(root)
        Edge.apply(root)

        Notifier.ensureChannel(this)
        MonitorWorker.schedule(this)
        askNotificationsOnce()
        Cache.loadAll(this, Store.all(this))
        updateNav()
        render()
        if (Store.all(this).isNotEmpty()) refreshAll()
    }

    override fun onResume() {
        super.onResume()
        // تحديث تلقائي عند العودة للتطبيق إذا مرّت 10 دقائق على آخر تحديث
        if (lastRefresh > 0 && !loading && Store.all(this).isNotEmpty() &&
            System.currentTimeMillis() - lastRefresh > 10 * 60 * 1000
        ) refreshAll()
    }

    override fun onDestroy() {
        web?.destroy()
        web = null
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            detail != null || guideHazard != null -> closeDetail()
            tab != 0 -> selectTab(0)
            else -> super.onBackPressed()
        }
    }

    private fun askNotificationsOnce() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            val p = getSharedPreferences("prefs", Context.MODE_PRIVATE)
            if (!p.getBoolean("askedNotif", false)) {
                p.edit().putBoolean("askedNotif", true).apply()
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2)
            }
        }
    }

    // علامة LRM تمنع اختلاط اتجاه الأرقام مع النص العربي
    private fun conv(c: Double): Double = if (Store.useF(this)) c * 9 / 5 + 32 else c
    private fun tmp(c: Double): String =
        "‎${conv(c).roundToInt()}°" + (if (Store.useF(this)) "F" else "") + "‎"

    private fun ago(time: Long): String {
        val m = ((System.currentTimeMillis() - time) / 60000).toInt()
        return when {
            m < 1 -> t("الآن", "just now")
            m < 60 -> t("قبل $m دقيقة", "$m min ago")
            else -> t("قبل ${m / 60} ساعة", "${m / 60} h ago")
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    // ======================= التنقل =======================

    private fun buildNav(): LinearLayout {
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Ui.SURFACE)
            setPadding(dp(8), dp(6), dp(8), dp(6))
        }
        val items = listOf(
            t("الرئيسية", "Home") to R.drawable.ic_nav_home,
            t("التنبيهات", "Alerts") to R.drawable.ic_nav_alert,
            t("الأقمار", "Satellite") to R.drawable.ic_nav_sat,
            t("المدن", "Cities") to R.drawable.ic_nav_city
        )
        items.forEachIndexed { i, (label, res) ->
            val item = col().apply {
                gravity = Gravity.CENTER_HORIZONTAL
                setPadding(0, dp(6), 0, dp(6))
                contentDescription = label
                addView(icon(res, 24, Ui.DIM))
                addView(tv(label, 11f, Ui.DIM, center = true))
                setOnClickListener { selectTab(i) }
            }
            bar.addView(item, lp(0, WRAP, weight = 1f))
            navItems += item
        }
        return bar
    }

    private fun updateNav() {
        navItems.forEachIndexed { i, item ->
            val sel = i == tab
            val color = if (sel) Ui.ACCENT else Ui.DIM
            (item.getChildAt(0) as ImageView).setColorFilter(color)
            (item.getChildAt(1) as TextView).setTextColor(color)
            item.background = if (sel) shape(Ui.withAlpha(Ui.ACCENT, 28), 14) else null
        }
    }

    private fun selectTab(i: Int) {
        tab = i
        detail = null
        guideHazard = null
        updateNav()
        render()
    }

    private fun closeDetail() {
        detail = null
        guideHazard = null
        render()
    }

    private fun render(keepScroll: Boolean = false) {
        val keepY = if (keepScroll) (content.getChildAt(0) as? ScrollView)?.scrollY ?: 0 else 0
        content.removeAllViews()
        if (detail != null || guideHazard != null) {
            renderDetail()
        } else {
            when (tab) {
                0 -> renderHome()
                1 -> renderAlerts()
                2 -> renderSat()
                else -> renderCities()
            }
        }
        if (keepY > 0) {
            (content.getChildAt(0) as? ScrollView)?.let { sv -> sv.post { sv.scrollY = keepY } }
        }
    }

    private fun screen(): LinearLayout {
        val sv = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        val box = col(16)
        sv.addView(box)
        content.addView(sv, FrameLayout.LayoutParams(MATCH, MATCH))
        return box
    }

    private fun brand() = t("حارس الأرض", "Earth Guardian")

    private fun titleBar(title: String, sub: String): LinearLayout = col().apply {
        setPadding(0, dp(4), 0, dp(8))
        addView(tv(brand(), 12f, Ui.ACCENT, true))
        addView(tv(title, 26f, Ui.TEXT, true))
        addView(tv(sub, 13f, Ui.DIM))
    }

    private fun button(label: String, primary: Boolean, onClick: () -> Unit): TextView =
        tv(label, 15f, if (primary) Ui.BG else Ui.TEXT, true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = if (primary) shape(Ui.ACCENT, 16) else shape(Ui.SURFACE2, 16, Ui.STROKE)
            setOnClickListener { onClick() }
        }

    private fun tag(label: String, color: Int): TextView =
        tv(label, 11f, color, true).apply {
            setPadding(dp(10), dp(3), dp(10), dp(3))
            background = shape(Ui.withAlpha(color, 38), 10)
            layoutParams = lp(WRAP, WRAP, e = 6)
        }

    // ======================= الرئيسية =======================

    private fun renderHome() {
        val city = Store.selected(this)
        val box = screen()
        if (city == null) {
            box.addView(titleBar(t("مرحباً بك", "Welcome"), t("مركز مراقبة الكوارث والطقس", "Disaster & weather monitoring centre")))
            box.addView(onboarding(), lp(MATCH, WRAP, t = 12))
            return
        }
        val rep = AppState.reports[city.key]
        val wx = AppState.weather[city.key]
        val level = rep?.overall() ?: 0
        val tone = if (rep == null) Ui.ACCENT else Ui.levelColor(level)

        // ---- الترويسة ----
        val head = row()
        val names = col().apply {
            addView(tv(brand(), 12f, Ui.ACCENT, true))
            val cr = row()
            cr.addView(icon(R.drawable.ic_nav_city, 22, Ui.ACCENT))
            cr.addView(tv(city.name, 26f, Ui.TEXT, true), lp(WRAP, WRAP, s = 6))
            addView(cr)
            val sub = if (city.gps) {
                t("حسب موقعك الحالي", "Based on your location") + (if (city.country.isNotBlank()) " • ${city.country}" else "")
            } else city.country
            addView(tv(sub, 12f, Ui.DIM))
            setOnClickListener { selectTab(3) }
        }
        head.addView(names, lp(0, WRAP, weight = 1f))
        val refresh = badge(R.drawable.ic_refresh, if (loading) Ui.DIM else Ui.ACCENT, 44)
        refresh.contentDescription = t("تحديث", "Refresh")
        refresh.setOnClickListener { refreshAll() }
        if (loading) {
            refresh.startAnimation(RotateAnimation(
                0f, 360f, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f
            ).apply {
                duration = 900
                repeatCount = Animation.INFINITE
                interpolator = LinearInterpolator()
            })
        }
        head.addView(refresh)
        box.addView(head)

        // ---- لا يوجد اتصال ----
        if (city.key in offline) {
            box.addView(
                tv(t("⚠️ لا يوجد اتصال بالإنترنت — تُعرض آخر بيانات محفوظة", "⚠️ No internet connection — showing last saved data"),
                    13f, Ui.WATCH, true).apply {
                    setPadding(dp(14), dp(10), dp(14), dp(10))
                    background = shape(Ui.withAlpha(Ui.WATCH, 32), 14)
                },
                lp(MATCH, WRAP, t = 10)
            )
        }

        // ---- بطاقة الحالة والطقس ----
        val hero = card(16)
        val top = row()
        val info = col()
        if (wx != null) {
            val n = wx.now
            info.addView(tv(tmp(n.temp), 52f, Ui.TEXT, true))
            val d = row()
            d.addView(icon(Wx.icon(n.code, n.isDay), 22, Wx.color(n.code)))
            d.addView(tv(Wx.desc(n.code), 16f, Ui.TEXT), lp(WRAP, WRAP, s = 8))
            info.addView(d)
            info.addView(tv(t("تبدو كأنها ", "Feels like ") + tmp(n.feels), 12f, Ui.DIM), lp(WRAP, WRAP, t = 4))
            val today = wx.days.firstOrNull()
            if (today != null) {
                info.addView(
                    tv(t("العظمى ", "High ") + tmp(today.tMax) + t("  •  الصغرى ", "  •  Low ") + tmp(today.tMin), 12f, Ui.DIM),
                    lp(WRAP, WRAP, t = 2)
                )
            }
        } else {
            info.addView(tv(if (loading) t("جارٍ تحميل الطقس…", "Loading weather…") else t("تعذّر تحميل الطقس", "Weather unavailable"), 16f, Ui.DIM))
        }
        top.addView(info, lp(0, WRAP, weight = 1f))
        val radar = RadarView(this).apply {
            this.tone = tone
            blips = rep?.alerts?.map { (it.id.hashCode() and 0x7fffffff) % 360 } ?: emptyList()
        }
        top.addView(radar, lp(dp(116), dp(116)))
        hero.addView(top)

        val statusText = when {
            rep == null -> if (loading) t("⏳ جارٍ جمع البيانات من الأقمار والمحطات…", "⏳ Collecting satellite and station data…") else t("لا توجد بيانات بعد", "No data yet")
            rep.allFailed() -> t("❌ تعذّر الاتصال بمصادر البيانات", "❌ Could not reach data sources")
            level == 0 -> t("✅ الوضع آمن في ${city.name}", "✅ All clear in ${city.name}")
            level == 1 -> t("🟠 ترقّب: توجد إنذارات مبكرة", "🟠 Watch: early warnings in effect")
            else -> t("🔴 خطر: توجد أحداث نشطة", "🔴 Danger: active events")
        }
        val pill = tv(statusText, 14f, tone, true).apply {
            setPadding(dp(14), dp(10), dp(14), dp(10))
            background = shape(Ui.withAlpha(tone, 32), 14)
        }
        hero.addView(pill, lp(MATCH, WRAP, t = 12))
        if (rep != null && rep.failed.isNotEmpty() && !rep.allFailed()) {
            hero.addView(tv(t("تعذّر الوصول إلى: ", "Unavailable: ") + rep.failed.joinToString(if (L.ar) "، " else ", "), 11f, Ui.DIM), lp(WRAP, WRAP, t = 6))
        }
        if (rep != null) {
            hero.addView(tv(t("آخر تحديث: ", "Last updated: ") + ago(rep.time), 11f, Ui.DIM), lp(WRAP, WRAP, t = 6))
        }
        box.addView(hero, lp(MATCH, WRAP, t = 12))

        // ---- مؤشرات سريعة ----
        if (wx != null) {
            val stats = row()
            stats.addView(stat(R.drawable.ic_h_flood, "${wx.now.humidity}%", t("الرطوبة", "Humidity")), lp(0, WRAP, weight = 1f))
            stats.addView(stat(R.drawable.ic_wind, "${wx.now.wind.roundToInt()} " + t("كم/س", "km/h"), t("الرياح", "Wind")), lp(0, WRAP, s = 8, weight = 1f))
            stats.addView(stat(R.drawable.ic_gauge, "${wx.now.pressure.roundToInt()}", t("الضغط (hPa)", "Pressure (hPa)")), lp(0, WRAP, s = 8, weight = 1f))
            box.addView(stats, lp(MATCH, WRAP, t = 12))
        }

        // ---- رادار المخاطر ----
        val grid = card(16)
        grid.addView(tv(t("رادار المخاطر", "Risk radar"), 17f, Ui.TEXT, true))
        grid.addView(tv(t("اضغط على أي خطر لعرض تفاصيله", "Tap a hazard for details"), 12f, Ui.DIM), lp(WRAP, WRAP, b = 10))
        for (rowItems in Hazard.values().toList().chunked(3)) {
            val r = row()
            rowItems.forEachIndexed { idx, h ->
                val lv = rep?.level(h) ?: 0
                val color = if (rep == null) Ui.DIM else Ui.levelColor(lv)
                val cell = col(8).apply {
                    gravity = Gravity.CENTER_HORIZONTAL
                    addView(badge(h.icon, color, 46))
                    addView(tv(h.short, 13f, Ui.TEXT, true, center = true), lp(MATCH, WRAP, t = 6))
                    addView(tv(if (rep == null) "—" else Ui.levelText(lv), 12f, color, true, center = true), lp(MATCH, WRAP))
                    setOnClickListener { filter = h; selectTab(1) }
                }
                r.addView(cell, lp(0, WRAP, s = if (idx == 0) 0 else 6, weight = 1f))
            }
            grid.addView(r, lp(MATCH, WRAP, t = 6))
        }
        box.addView(grid, lp(MATCH, WRAP, t = 12))

        // ---- أبرز التنبيهات ----
        val alerts = (rep?.alerts ?: emptyList()).sortedBy { if (it.forecast) 1 else 0 }
        if (alerts.isNotEmpty()) {
            box.addView(tv(t("أبرز التنبيهات", "Top alerts"), 17f, Ui.TEXT, true), lp(WRAP, WRAP, t = 16, b = 8))
            alerts.take(3).forEach { box.addView(alertCard(it, city, false), lp(MATCH, WRAP, b = 10)) }
            if (alerts.size > 3) {
                box.addView(button(t("عرض كل التنبيهات (${alerts.size})", "View all alerts (${alerts.size})"), false) { filter = null; selectTab(1) })
            }
        }

        // ---- دليل السلامة ----
        val gc = card(16)
        gc.addView(tv(t("دليل السلامة", "Safety guide"), 17f, Ui.TEXT, true))
        gc.addView(tv(t("ماذا تفعل أثناء الخطر وبعده", "What to do during and after a hazard"), 12f, Ui.DIM), lp(WRAP, WRAP, b = 10))
        val gh = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val gr = row()
        Hazard.values().forEach { h ->
            gr.addView(
                tv(h.short, 13f, Ui.TEXT, true).apply {
                    setPadding(dp(14), dp(9), dp(14), dp(9))
                    background = shape(Ui.SURFACE2, 18, Ui.STROKE)
                    setOnClickListener { guideHazard = h; detail = null; render() }
                },
                lp(WRAP, WRAP, e = 8)
            )
        }
        gh.addView(gr)
        gc.addView(gh)
        box.addView(gc, lp(MATCH, WRAP, t = 16))

        // ---- نصيحة البطارية (مرة واحدة) ----
        if (!Store.battTipDismissed(this)) {
            val bc = card(16)
            bc.addView(tv(t("لضمان وصول التنبيهات", "Make sure alerts reach you"), 15f, Ui.TEXT, true))
            bc.addView(
                tv(t("بعض الهواتف توقف التطبيقات في الخلفية لتوفير البطارية فقد تتأخر التنبيهات. اسمح للتطبيق بالعمل دون قيود من إعدادات البطارية.",
                    "Some phones stop background apps to save battery, which can delay alerts. Allow this app to run without restrictions in battery settings."),
                    12f, Ui.DIM),
                lp(MATCH, WRAP, t = 4, b = 10)
            )
            val br = row()
            br.addView(button(t("فتح الإعدادات", "Open settings"), true) { openBatterySettings() }, lp(0, WRAP, weight = 1f))
            br.addView(button(t("إخفاء", "Dismiss"), false) { Store.dismissBattTip(this); render(true) }, lp(0, WRAP, s = 8, weight = 1f))
            bc.addView(br)
            box.addView(bc, lp(MATCH, WRAP, t = 12))
        }

        // ---- 24 ساعة ----
        if (wx != null) {
            val ch = card(16)
            ch.addView(tv(t("الحرارة خلال 24 ساعة", "Next 24 hours"), 17f, Ui.TEXT, true))
            val chart = HourlyChart(this).apply {
                temps = wx.hourTemps.map { conv(it) }
                startHour = wx.startHour
            }
            ch.addView(chart, lp(MATCH, dp(170), t = 6))
            box.addView(ch, lp(MATCH, WRAP, t = 16))

            val dc = card(16)
            dc.addView(tv(t("توقعات 7 أيام", "7-day forecast"), 17f, Ui.TEXT, true), lp(WRAP, WRAP, b = 6))
            wx.days.forEachIndexed { i, d ->
                val r = row().apply { setPadding(0, dp(8), 0, dp(8)) }
                r.addView(tv(Weather.dayName(d.date, i), 15f, Ui.TEXT, i == 0), lp(0, WRAP, weight = 1.2f))
                r.addView(icon(Wx.icon(d.code, true), 24, Wx.color(d.code)))
                r.addView(tv(if (d.rain >= 1) "${d.rain.roundToInt()} " + t("مم", "mm") else "", 12f, Ui.ACCENT), lp(dp(56), WRAP, s = 8))
                r.addView(tv(tmp(d.tMax), 15f, Ui.TEXT, true), lp(dp(54), WRAP))
                r.addView(tv(tmp(d.tMin), 15f, Ui.DIM), lp(dp(54), WRAP))
                dc.addView(r)
            }
            box.addView(dc, lp(MATCH, WRAP, t = 12))
        }

        box.addView(
            tv(t("«التوقعات» مبنية على اتجاهات الطقس والنشاط الزلزالي وهي احتمالية، ولا يمكن التنبؤ بموعد الزلازل. التطبيق مساعد إضافي غير رسمي ولا يغني عن التحذيرات الرسمية.",
                "“Forecasts” are based on weather and seismic trends and are probabilistic; earthquakes cannot be predicted. This is an unofficial helper app and does not replace official warnings."),
                11f, Ui.DIM),
            lp(MATCH, WRAP, t = 16, b = 8)
        )
    }

    private fun stat(res: Int, value: String, label: String): LinearLayout = col(12).apply {
        background = shape(Ui.SURFACE, 16, Ui.STROKE)
        gravity = Gravity.CENTER_HORIZONTAL
        addView(icon(res, 20, Ui.ACCENT))
        addView(tv(value, 15f, Ui.TEXT, true, center = true), lp(WRAP, WRAP, t = 4))
        addView(tv(label, 11f, Ui.DIM, center = true))
    }

    private fun onboarding(): LinearLayout {
        val c = card(20)
        c.gravity = Gravity.CENTER_HORIZONTAL
        val radar = RadarView(this).apply { tone = Ui.ACCENT }
        c.addView(radar, lp(dp(150), dp(150)))
        c.addView(tv(brand(), 24f, Ui.TEXT, true), lp(WRAP, WRAP, t = 12))
        c.addView(
            tv(t("يراقب الزلازل والعواصف والفيضانات والبراكين والحر والبرد في مدينتك، عبر بيانات الأقمار الصناعية ومراكز الرصد، وينبّهك قبل أن يتفاقم الخطر.",
                "Monitors earthquakes, storms, floods, volcanoes, heat and cold in your city using satellite and observatory data, and alerts you before danger escalates."),
                14f, Ui.DIM).apply { gravity = Gravity.CENTER },
            lp(MATCH, WRAP, t = 8, b = 16)
        )
        c.addView(button(t("📍 استخدم موقعي الحالي", "📍 Use my location"), true) { useMyLocation() }, lp(MATCH, WRAP))
        c.addView(button(t("🔎 اختر مدينة", "🔎 Choose a city"), false) { selectTab(3) }, lp(MATCH, WRAP, t = 10))
        return c
    }

    private fun openBatterySettings() {
        try {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        } catch (e: Exception) {
            try {
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
            } catch (_: Exception) {
            }
        }
    }

    // ======================= التنبيهات =======================

    private fun alertCard(a: Alert, city: City?, showCity: Boolean, clickable: Boolean = true): LinearLayout {
        val tone = if (a.forecast) Ui.WATCH else Ui.DANGER
        val r = row().apply {
            gravity = Gravity.TOP
            setPadding(dp(14), dp(14), dp(14), dp(14))
            background = shape(Ui.SURFACE, 18, Ui.withAlpha(tone, 120))
            if (clickable) setOnClickListener { detail = Pair(city, a); guideHazard = null; render() }
        }
        r.addView(badge(a.hazard.icon, tone, 44))
        val c = col().apply {
            addView(tv(a.title, 16f, Ui.TEXT, true))
            addView(tv(a.body, 13f, Ui.DIM), lp(MATCH, WRAP, t = 4, b = 8))
            val tags = row()
            tags.addView(tag(if (a.forecast) t("توقع", "Forecast") else t("حدث", "Event"), tone))
            if (a.official) tags.addView(tag(t("رسمي", "Official"), Ui.ACCENT))
            if (showCity && city != null) tags.addView(tag(city.name, Ui.DIM))
            if (clickable) tags.addView(tag(t("ماذا أفعل؟", "What to do?"), Ui.OK))
            addView(tags)
        }
        r.addView(c, lp(0, WRAP, s = 12, weight = 1f))
        return r
    }

    private fun renderAlerts() {
        val box = screen()
        box.addView(titleBar(t("التنبيهات", "Alerts"), t("أحداث فعلية وتوقعات مبنية على التغيّرات", "Live events and trend-based forecasts")))

        val hs = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val chips = row()
        fun chip(label: String, h: Hazard?) {
            val sel = filter == h
            chips.addView(
                tv(label, 13f, if (sel) Ui.BG else Ui.TEXT, true).apply {
                    setPadding(dp(14), dp(8), dp(14), dp(8))
                    background = if (sel) shape(Ui.ACCENT, 18) else shape(Ui.SURFACE, 18, Ui.STROKE)
                    setOnClickListener { filter = h; render() }
                },
                lp(WRAP, WRAP, e = 8)
            )
        }
        chip(t("الكل", "All"), null)
        Hazard.values().forEach { chip(it.short, it) }
        hs.addView(chips)
        box.addView(hs, lp(MATCH, WRAP, t = 8, b = 12))

        val cities = Store.all(this)
        val items = cities.flatMap { c ->
            (AppState.reports[c.key]?.alerts ?: emptyList()).map { c to it }
        }.filter { filter == null || it.second.hazard == filter }
            .sortedBy { if (it.second.forecast) 1 else 0 }

        if (items.isEmpty()) {
            val msg = when {
                cities.isEmpty() -> t("أضف مدينة أولاً من تبويب «المدن».", "Add a city first from the Cities tab.")
                loading -> t("⏳ جارٍ الفحص…", "⏳ Checking…")
                else -> t("✅ لا توجد تنبيهات", "✅ No alerts") +
                    (if (filter != null) t(" في هذا القسم", " in this category") else "") +
                    t(" حالياً.\nالمراقبة تعمل في الخلفية كل 15 دقيقة.", " right now.\nMonitoring runs in the background every 15 minutes.")
            }
            box.addView(
                card(20).apply { addView(tv(msg, 15f, Ui.DIM).apply { gravity = Gravity.CENTER }) },
                lp(MATCH, WRAP)
            )
            val f = filter
            if (f != null) {
                box.addView(button(t("دليل السلامة: ", "Safety guide: ") + f.short, false) { guideHazard = f; detail = null; render() }, lp(MATCH, WRAP, t = 10))
            }
        } else {
            items.forEach { (c, a) ->
                box.addView(alertCard(a, c, cities.size > 1), lp(MATCH, WRAP, b = 10))
            }
        }
    }

    // ======================= تفاصيل التنبيه ودليل السلامة =======================

    private fun bullet(s: String): LinearLayout = row().apply {
        gravity = Gravity.TOP
        setPadding(0, dp(6), 0, dp(6))
        addView(tv("•", 14f, Ui.ACCENT, true))
        addView(tv(s, 14f, Ui.TEXT), lp(0, WRAP, s = 8, weight = 1f))
    }

    private fun dial(num: String) {
        val n = num.filter { it.isDigit() }
        if (n.isEmpty()) return
        try {
            startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$n")))
        } catch (_: Exception) {
        }
    }

    private fun renderDetail() {
        val box = screen()
        val back = row().apply {
            setPadding(0, dp(8), 0, dp(12))
            setOnClickListener { closeDetail() }
            addView(icon(R.drawable.ic_chevron, 22, Ui.ACCENT).apply { rotation = if (L.ar) 0f else 180f })
            addView(tv(t("رجوع", "Back"), 15f, Ui.ACCENT, true), lp(WRAP, WRAP, s = 4))
        }
        box.addView(back)

        val alert = detail?.second
        val city = detail?.first ?: Store.selected(this)
        val hz = alert?.hazard ?: guideHazard ?: Hazard.QUAKE

        if (alert != null) {
            box.addView(alertCard(alert, city, true, clickable = false), lp(MATCH, WRAP, b = 4))
        } else {
            val h = row()
            h.addView(badge(hz.icon, Ui.ACCENT, 48))
            h.addView(tv(t("دليل السلامة: ", "Safety guide: ") + hz.label, 20f, Ui.TEXT, true), lp(0, WRAP, s = 12, weight = 1f))
            box.addView(h, lp(MATCH, WRAP, b = 4))
        }

        box.addView(tv(t("ماذا أفعل؟", "What should I do?"), 18f, Ui.TEXT, true), lp(WRAP, WRAP, t = 14))
        Guide.sections(hz).forEach { sec ->
            val c = card(16)
            c.addView(tv(sec.title, 16f, Ui.ACCENT, true), lp(WRAP, WRAP, b = 4))
            sec.items.forEach { c.addView(bullet(it)) }
            box.addView(c, lp(MATCH, WRAP, t = 10))
        }

        val ec = card(16)
        ec.addView(tv(t("أرقام الطوارئ", "Emergency numbers"), 16f, Ui.DANGER, true), lp(WRAP, WRAP, b = 6))
        val nums = Guide.emergency(city?.cc ?: "")
        if (nums != null) {
            nums.forEach { (label, num) ->
                val r = row().apply {
                    setPadding(0, dp(8), 0, dp(8))
                    setOnClickListener { dial(num) }
                }
                r.addView(tv(label, 15f, Ui.TEXT), lp(0, WRAP, weight = 1f))
                r.addView(tv("‎$num", 20f, Ui.ACCENT, true))
                ec.addView(r)
            }
            ec.addView(tv(t("اضغط على الرقم للاتصال. تحقق من الرقم المحلي عند السفر.", "Tap a number to dial. Verify local numbers when travelling."), 11f, Ui.DIM), lp(WRAP, WRAP, t = 4))
        } else {
            ec.addView(tv(t("تحقق من رقم الطوارئ المحلي في بلدك. الرقم 112 قد يعمل من الجوال في كثير من الدول.",
                "Check your local emergency number. 112 may work from a mobile phone in many countries."), 13f, Ui.DIM))
        }
        box.addView(ec, lp(MATCH, WRAP, t = 10))

        box.addView(
            tv(t("هذه إرشادات عامة وليست بديلاً عن تعليمات الدفاع المدني والجهات الرسمية. في حال الخطر الفوري اتصل بالطوارئ.",
                "These are general guidelines, not a substitute for instructions from civil defence and official authorities. In immediate danger, call emergency services."),
                11f, Ui.DIM),
            lp(MATCH, WRAP, t = 12, b = 8)
        )
    }

    // ======================= الأقمار الصناعية =======================

    @SuppressLint("SetJavaScriptEnabled")
    private fun webView(): WebView = web ?: WebView(this).also { w ->
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.webViewClient = WebViewClient()
        w.setBackgroundColor(Ui.BG)
        web = w
    }

    private fun renderSat() {
        val city = Store.selected(this)
        val box = col(16)
        box.addView(titleBar(
            t("الأقمار الصناعية", "Satellite view"),
            if (city != null) t("أمطار وسحب فوق ${city.name} (NASA GIBS)", "Rain and clouds over ${city.name} (NASA GIBS)") else t("اختر مدينة أولاً", "Choose a city first")
        ))
        if (city == null) {
            box.addView(button(t("اختر مدينة", "Choose a city"), true) { selectTab(3) })
        } else {
            val w = webView()
            val key = city.key + "|" + L.ar
            if (webKey != key) {
                w.loadUrl("file:///android_asset/map.html?lat=${city.lat}&lon=${city.lon}&lang=" + (if (L.ar) "ar" else "en"))
                webKey = key
            }
            (w.parent as? android.view.ViewGroup)?.removeView(w)
            box.addView(w, lp(MATCH, 0, weight = 1f))
        }
        content.addView(box, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    // ======================= المدن =======================

    private fun renderCities() {
        val box = screen()
        box.addView(titleBar(t("مدني", "My cities"), t("اختر المدن التي تريد مراقبتها", "Choose the cities you want to monitor")))

        // بحث
        val sr = row().apply {
            background = shape(Ui.SURFACE, 16, Ui.STROKE)
            setPadding(dp(12), 0, dp(8), 0)
        }
        val et = EditText(this).apply {
            hint = t("ابحث عن مدينة (مثل: Miami أو القاهرة)", "Search for a city (e.g. Miami or Cairo)")
            setHintTextColor(Ui.DIM)
            setTextColor(Ui.TEXT)
            textSize = 15f
            background = null
            isSingleLine = true
            inputType = InputType.TYPE_CLASS_TEXT
            imeOptions = EditorInfo.IME_ACTION_SEARCH
            setText(query)
            doAfterTextChanged { query = it?.toString() ?: "" }
            setOnEditorActionListener { v, id, _ ->
                if (id == EditorInfo.IME_ACTION_SEARCH) {
                    searchCity(v.text.toString())
                    true
                } else false
            }
        }
        sr.addView(icon(R.drawable.ic_search, 22, Ui.ACCENT).apply {
            contentDescription = t("بحث", "Search")
            setOnClickListener { searchCity(et.text.toString()) }
        })
        sr.addView(et, lp(0, dp(50), s = 8, weight = 1f))
        box.addView(sr, lp(MATCH, WRAP, t = 8))

        resultsBox = col()
        box.addView(resultsBox, lp(MATCH, WRAP))
        fillResults()

        box.addView(button(t("📍 استخدم موقعي الحالي (GPS)", "📍 Use my current location (GPS)"), true) { useMyLocation() }, lp(MATCH, WRAP, t = 10))

        // المدن المحفوظة
        val all = Store.all(this)
        val sel = Store.selected(this)
        box.addView(tv(t("المدن المراقَبة (${all.size})", "Monitored cities (${all.size})"), 17f, Ui.TEXT, true), lp(WRAP, WRAP, t = 18, b = 8))
        if (all.isEmpty()) {
            box.addView(tv(t("لا توجد مدن بعد. ابحث عن مدينة أو اختر من القائمة أدناه.", "No cities yet. Search for a city or pick one below."), 13f, Ui.DIM))
        }
        all.forEach { c ->
            val rep = AppState.reports[c.key]
            val color = if (rep == null) Ui.DIM else Ui.levelColor(rep.overall())
            val r = row().apply {
                setPadding(dp(14), dp(12), dp(8), dp(12))
                background = shape(Ui.SURFACE, 16, if (sel?.key == c.key) Ui.ACCENT else Ui.STROKE)
                setOnClickListener { selectCity(c) }
            }
            r.addView(badge(if (c.gps) R.drawable.ic_gps else R.drawable.ic_nav_city, color, 40))
            val names = col().apply {
                addView(tv(c.name, 16f, Ui.TEXT, true))
                val sub = (if (c.gps) t("موقعك الحالي", "Your location") + (if (c.country.isNotBlank()) " • ${c.country}" else "") else c.country) +
                    (if (rep != null) " • " + Ui.levelText(rep.overall()) else "")
                addView(tv(sub, 12f, Ui.DIM))
            }
            r.addView(names, lp(0, WRAP, s = 12, weight = 1f))
            r.addView(icon(R.drawable.ic_close, 36, Ui.DIM).apply {
                contentDescription = t("حذف", "Remove")
                setPadding(dp(8), dp(8), dp(8), dp(8))
                setOnClickListener { removeCity(c) }
            })
            box.addView(r, lp(MATCH, WRAP, b = 8))
        }

        // مدن شائعة
        box.addView(tv(t("مدن شائعة", "Popular cities"), 17f, Ui.TEXT, true), lp(WRAP, WRAP, t = 18, b = 8))
        for (group in Popular.list().chunked(3)) {
            val r = row()
            group.forEachIndexed { idx, c ->
                r.addView(
                    tv(c.name, 13f, Ui.TEXT).apply {
                        gravity = Gravity.CENTER
                        setPadding(dp(6), dp(10), dp(6), dp(10))
                        background = shape(Ui.SURFACE, 14, Ui.STROKE)
                        setOnClickListener { addCity(c) }
                    },
                    lp(0, WRAP, s = if (idx == 0) 0 else 8, weight = 1f)
                )
            }
            box.addView(r, lp(MATCH, WRAP, b = 8))
        }

        // الإعدادات
        val st = card(16)
        st.addView(tv(t("الإعدادات", "Settings"), 15f, Ui.TEXT, true), lp(WRAP, WRAP, b = 4))

        st.addView(tv(t("اللغة", "Language"), 13f, Ui.DIM), lp(WRAP, WRAP, t = 6, b = 6))
        val lr = row()
        fun langChip(label: String, v: String) {
            val on = L.pref(this) == v
            lr.addView(
                tv(label, 13f, if (on) Ui.BG else Ui.TEXT, true).apply {
                    setPadding(dp(14), dp(8), dp(14), dp(8))
                    background = if (on) shape(Ui.ACCENT, 18) else shape(Ui.SURFACE2, 18, Ui.STROKE)
                    setOnClickListener {
                        if (!on) {
                            L.setPref(this@MainActivity, v)
                            L.init(this@MainActivity)
                            recreate()
                        }
                    }
                },
                lp(WRAP, WRAP, e = 8)
            )
        }
        langChip(t("تلقائي", "Auto"), "auto")
        langChip("العربية", "ar")
        langChip("English", "en")
        st.addView(lr)

        fun sw(label: String, on: Boolean, onChange: (Boolean) -> Unit) {
            st.addView(Switch(this).apply {
                text = label
                textSize = 14f
                setTextColor(Ui.TEXT)
                isChecked = on
                setPadding(0, dp(10), 0, dp(10))
                setOnCheckedChangeListener { _, v -> onChange(v) }
            }, lp(MATCH, WRAP, t = 6))
        }
        sw(t("إشعارات التوقعات المبكرة (غير الأحداث الفعلية)", "Early-forecast notifications (not live events)"), Store.forecastNotifs(this)) { Store.setForecastNotifs(this, it) }
        sw(t("عرض الحرارة بالفهرنهايت °F", "Show temperature in Fahrenheit °F"), Store.useF(this)) {
            Store.setUseF(this, it)
        }
        st.addView(button(t("إعدادات البطارية (لضمان وصول التنبيهات)", "Battery settings (to keep alerts reliable)"), false) { openBatterySettings() }, lp(MATCH, WRAP, t = 8))
        box.addView(st, lp(MATCH, WRAP, t = 18))

        // عن التطبيق
        val about = card(16)
        about.addView(tv(t("عن حارس الأرض", "About Earth Guardian"), 15f, Ui.TEXT, true))
        about.addView(
            tv(t("المصادر: USGS (زلازل) • Open-Meteo (طقس ومناخ وفيضانات) • NASA EONET وNASA GIBS (أقمار صناعية) • NWS (تحذيرات أمريكا الرسمية) • GDACS (أعاصير وفيضانات وبراكين عالمياً).\nمواقعك ومدنك تُحفظ على جهازك فقط ولا نملك خادماً.\nتطبيق غير رسمي ولا يمثل أي جهة حكومية.",
                "Sources: USGS (earthquakes) • Open-Meteo (weather, climate, floods) • NASA EONET & NASA GIBS (satellites) • NWS (official US warnings) • GDACS (global cyclones, floods, volcanoes).\nYour locations and cities are stored only on your device; we run no server.\nAn unofficial app that does not represent any government body."),
                12f, Ui.DIM),
            lp(MATCH, WRAP, t = 6)
        )
        box.addView(about, lp(MATCH, WRAP, t = 12, b = 8))
    }

    private fun fillResults() {
        val b = resultsBox ?: return
        b.removeAllViews()
        searchMsg?.let { b.addView(tv(it, 13f, Ui.DIM), lp(WRAP, WRAP, t = 8, b = 4)) }
        searchResults.forEach { c ->
            val r = row().apply {
                setPadding(dp(14), dp(12), dp(14), dp(12))
                background = shape(Ui.SURFACE2, 16, Ui.STROKE)
                setOnClickListener { addCity(c) }
            }
            r.addView(icon(R.drawable.ic_nav_city, 22, Ui.ACCENT))
            val names = col().apply {
                addView(tv(c.name, 15f, Ui.TEXT, true))
                addView(tv(c.country, 12f, Ui.DIM))
            }
            r.addView(names, lp(0, WRAP, s = 10, weight = 1f))
            r.addView(tv(t("+ إضافة", "+ Add"), 13f, Ui.ACCENT, true))
            b.addView(r, lp(MATCH, WRAP, t = 8))
        }
    }

    private fun searchCity(q: String) {
        if (q.isBlank()) return
        searchMsg = t("جارٍ البحث…", "Searching…")
        searchResults = emptyList()
        fillResults()
        thread {
            val list = try { Geo.search(q) } catch (e: Exception) { null }
            runOnUiThread {
                if (isFinishing) return@runOnUiThread
                searchResults = list ?: emptyList()
                searchMsg = when {
                    list == null -> t("تعذّر البحث، تحقق من الإنترنت.", "Search failed. Check your internet connection.")
                    list.isEmpty() -> t("لا توجد نتائج.", "No results.")
                    else -> null
                }
                fillResults()
            }
        }
    }

    private fun addCity(c: City) {
        if (!Store.add(this, c)) {
            toast(t("الحد الأقصى ${Store.MAX_SAVED} مدن. احذف مدينة أولاً.", "Maximum ${Store.MAX_SAVED} cities. Remove one first."))
            return
        }
        searchResults = emptyList()
        searchMsg = null
        selectCity(c)
    }

    private fun removeCity(c: City) {
        Store.remove(this, c)
        AppState.reports.remove(c.key)
        AppState.weather.remove(c.key)
        offline -= c.key
        render()
    }

    private fun selectCity(c: City) {
        Store.setSelected(this, c)
        filter = null
        tab = 0
        detail = null
        guideHazard = null
        updateNav()
        render()
        val rep = AppState.reports[c.key]
        val stale = rep == null || System.currentTimeMillis() - rep.time > 10 * 60 * 1000 || AppState.weather[c.key] == null
        if (stale) refreshAll()
    }

    // ======================= جلب البيانات =======================

    private fun refreshAll() {
        if (loading) {
            pendingRefresh = true
            return
        }
        val sel = Store.selected(this)
        val cities = Store.all(this).sortedBy { if (it.key == sel?.key) 0 else 1 }
        if (cities.isEmpty()) return
        loading = true
        render(true)
        thread {
            for ((i, c) in cities.withIndex()) {
                val rep = try {
                    Checker.check(this, c)
                } catch (e: Exception) {
                    Report(c, emptyList(), listOf("all"), 1)
                }
                val wx = try { Weather.fetch(c.lat, c.lon) } catch (e: Exception) { null }
                runOnUiThread {
                    val keepOld = rep.allFailed() && AppState.reports[c.key] != null
                    if (keepOld) {
                        // لا اتصال: نُبقي آخر بيانات محفوظة ولا نستبدلها بنتيجة فارغة
                        offline += c.key
                        if (wx != null) {
                            AppState.weather[c.key] = wx
                            Cache.save(this, c.key, null, wx)
                        }
                    } else {
                        offline -= c.key
                        AppState.reports[c.key] = rep
                        if (wx != null) AppState.weather[c.key] = wx
                        Cache.save(this, c.key, rep, wx)
                    }
                    if (!isFinishing && i == 0 && tab != 3) render(true)
                }
                if (!rep.allFailed()) runCatching { Notifier.notifyNew(this, c, rep.alerts) }
            }
            runOnUiThread {
                loading = false
                lastRefresh = System.currentTimeMillis()
                if (!isFinishing) {
                    if (pendingRefresh) {
                        pendingRefresh = false
                        refreshAll()
                    } else {
                        render(true)
                    }
                }
            }
        }
    }

    // ======================= الموقع =======================

    private fun useMyLocation() {
        val has = listOf(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION)
            .any { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }
        if (!has) {
            wantGps = true
            requestPermissions(
                arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION), 1
            )
            return
        }
        locate()
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        if (code != 1) return
        val ok = results.any { it == PackageManager.PERMISSION_GRANTED }
        if (ok && wantGps) locate()
        else if (!ok) toast(t("بدون إذن الموقع يمكنك اختيار مدينة يدوياً من تبويب «المدن».", "Without location permission you can pick a city manually from the Cities tab."))
        wantGps = false
    }

    @Suppress("MissingPermission", "DEPRECATION")
    private fun locate() {
        toast(t("جارٍ تحديد موقعك…", "Finding your location…"))
        val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val providers = lm.getProviders(true).filter { it != LocationManager.PASSIVE_PROVIDER }
        val last = providers
            .mapNotNull { runCatching { lm.getLastKnownLocation(it) }.getOrNull() }
            .maxByOrNull { it.time }
        if (last != null) {
            onLocation(last)
            return
        }
        val provider = providers.firstOrNull { it == LocationManager.NETWORK_PROVIDER } ?: providers.firstOrNull()
        if (provider == null) {
            toast(t("فعّل خدمة الموقع (GPS) ثم أعد المحاولة، أو اختر مدينة يدوياً.", "Turn on location services (GPS) and try again, or choose a city manually."))
            return
        }
        var done = false
        val listener = object : LocationListener {
            override fun onLocationChanged(loc: Location) {
                done = true
                lm.removeUpdates(this)
                onLocation(loc)
            }
            override fun onProviderEnabled(p: String) {}
            override fun onProviderDisabled(p: String) {}
            @Deprecated("old API")
            override fun onStatusChanged(p: String?, s: Int, e: Bundle?) {}
        }
        lm.requestLocationUpdates(provider, 0L, 0f, listener, Looper.getMainLooper())
        Handler(Looper.getMainLooper()).postDelayed({
            if (!done) {
                lm.removeUpdates(listener)
                toast(t("تعذّر تحديد موقعك. اخرج لمكان مفتوح أو اختر مدينة يدوياً من تبويب «المدن».", "Could not get your location. Move to an open area or choose a city manually from the Cities tab."))
            }
        }, 25000)
    }

    private fun onLocation(loc: Location) {
        Store.setGps(this, loc.latitude, loc.longitude)
        nameLocation(loc.latitude, loc.longitude)
        Store.gps(this)?.let { Store.setSelected(this, it) }
        filter = null
        tab = 0
        detail = null
        guideHazard = null
        updateNav()
        render()
        refreshAll()
    }

    /** يحوّل الإحداثيات إلى اسم مدينة (إن توفرت خدمة Geocoder في الجهاز)، وإلا يبقى «موقعي الحالي». */
    @Suppress("DEPRECATION")
    private fun nameLocation(lat: Double, lon: Double) {
        thread {
            try {
                if (!android.location.Geocoder.isPresent()) return@thread
                val g = android.location.Geocoder(this, java.util.Locale(if (L.ar) "ar" else "en"))
                val a = g.getFromLocation(lat, lon, 1)?.firstOrNull() ?: return@thread
                val name = a.locality ?: a.subAdminArea ?: a.adminArea ?: return@thread
                Store.setGpsName(this, name, a.countryName ?: "", a.countryCode ?: "")
                runOnUiThread { if (!isFinishing) render(true) }
            } catch (_: Exception) {
            }
        }
    }
}
