package com.example.disasteralert

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Handler
import android.os.Bundle
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.animation.Animation
import android.view.animation.LinearInterpolator
import android.view.animation.RotateAnimation
import android.view.inputmethod.EditorInfo
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.core.widget.doAfterTextChanged
import kotlin.concurrent.thread
import kotlin.math.roundToInt

class MainActivity : Activity() {

    private lateinit var content: FrameLayout
    private val navItems = mutableListOf<LinearLayout>()
    private var tab = 0
    private var filter: Hazard? = null
    private var loading = false
    private var pendingRefresh = false
    private var lastRefresh = 0L
    private var wantGps = false
    private var web: WebView? = null
    private var webKey: String? = null
    private var searchResults: List<City> = emptyList()
    private var searchMsg: String? = null
    private var resultsBox: LinearLayout? = null
    private var query = ""

    // ======================= دورة الحياة =======================

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui.BG)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        content = FrameLayout(this)
        root.addView(content, lp(MATCH, 0, weight = 1f))
        root.addView(View(this).apply { setBackgroundColor(Ui.STROKE) }, lp(MATCH, dp(1)))
        root.addView(buildNav(), lp(MATCH, WRAP))
        setContentView(root)
        Edge.apply(root)

        Notifier.ensureChannel(this)
        MonitorWorker.schedule(this)
        askNotificationsOnce()
        updateNav()
        render()
        if (Store.all(this).isNotEmpty()) refreshAll()
    }

    override fun onResume() {
        super.onResume()
        // تحديث تلقائي عند العودة للتطبيق إذا مرّت 10 دقائق على آخر تحديث
        if (lastRefresh > 0 && !loading && Store.all(this).isNotEmpty() &&
            System.currentTimeMillis() - lastRefresh > 10 * 60 * 1000
        ) refreshAll()
    }

    override fun onDestroy() {
        web?.destroy()
        web = null
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (tab != 0) selectTab(0) else super.onBackPressed()
    }

    private fun askNotificationsOnce() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            val p = getSharedPreferences("prefs", Context.MODE_PRIVATE)
            if (!p.getBoolean("askedNotif", false)) {
                p.edit().putBoolean("askedNotif", true).apply()
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2)
            }
        }
    }

    private fun conv(c: Double): Double = if (Store.useF(this)) c * 9 / 5 + 32 else c
    private fun tmp(c: Double): String = "${conv(c).roundToInt()}°" + if (Store.useF(this)) "F" else ""

    private fun ago(t: Long): String {
        val m = ((System.currentTimeMillis() - t) / 60000).toInt()
        return when {
            m < 1 -> "الآن"
            m < 60 -> "قبل $m دقيقة"
            else -> "قبل ${m / 60} ساعة"
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    // ======================= التنقل =======================

    private fun buildNav(): LinearLayout {
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Ui.SURFACE)
            setPadding(dp(8), dp(6), dp(8), dp(6))
        }
        val items = listOf(
            "الرئيسية" to R.drawable.ic_nav_home,
            "التنبيهات" to R.drawable.ic_nav_alert,
            "الأقمار" to R.drawable.ic_nav_sat,
            "المدن" to R.drawable.ic_nav_city
        )
        items.forEachIndexed { i, (label, res) ->
            val item = col().apply {
                gravity = Gravity.CENTER_HORIZONTAL
                setPadding(0, dp(6), 0, dp(6))
                addView(icon(res, 24, Ui.DIM))
                addView(tv(label, 11f, Ui.DIM, center = true))
                setOnClickListener { selectTab(i) }
            }
            bar.addView(item, lp(0, WRAP, weight = 1f))
            navItems += item
        }
        return bar
    }

    private fun updateNav() {
        navItems.forEachIndexed { i, item ->
            val sel = i == tab
            val color = if (sel) Ui.ACCENT else Ui.DIM
            (item.getChildAt(0) as ImageView).setColorFilter(color)
            (item.getChildAt(1) as TextView).setTextColor(color)
            item.background = if (sel) shape(Ui.withAlpha(Ui.ACCENT, 28), 14) else null
        }
    }

    private fun selectTab(i: Int) {
        tab = i
        updateNav()
        render()
    }

    private fun render(keepScroll: Boolean = false) {
        val keepY = if (keepScroll) (content.getChildAt(0) as? ScrollView)?.scrollY ?: 0 else 0
        content.removeAllViews()
        when (tab) {
            0 -> renderHome()
            1 -> renderAlerts()
            2 -> renderSat()
            else -> renderCities()
        }
        if (keepY > 0) {
            (content.getChildAt(0) as? ScrollView)?.let { sv -> sv.post { sv.scrollY = keepY } }
        }
    }

    private fun screen(): LinearLayout {
        val sv = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        val box = col(16)
        sv.addView(box)
        content.addView(sv, FrameLayout.LayoutParams(MATCH, MATCH))
        return box
    }

    private fun titleBar(title: String, sub: String): LinearLayout = col().apply {
        setPadding(0, dp(4), 0, dp(8))
        addView(tv("حارس الأرض", 12f, Ui.ACCENT, true))
        addView(tv(title, 26f, Ui.TEXT, true))
        addView(tv(sub, 13f, Ui.DIM))
    }

    private fun button(label: String, primary: Boolean, onClick: () -> Unit): TextView =
        tv(label, 15f, if (primary) Ui.BG else Ui.TEXT, true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = if (primary) shape(Ui.ACCENT, 16) else shape(Ui.SURFACE2, 16, Ui.STROKE)
            setOnClickListener { onClick() }
        }

    private fun tag(label: String, color: Int): TextView =
        tv(label, 11f, color, true).apply {
            setPadding(dp(10), dp(3), dp(10), dp(3))
            background = shape(Ui.withAlpha(color, 38), 10)
            layoutParams = lp(WRAP, WRAP, e = 6)
        }

    // ======================= الرئيسية =======================

    private fun renderHome() {
        val city = Store.selected(this)
        val box = screen()
        if (city == null) {
            box.addView(titleBar("مرحباً بك", "مركز مراقبة الكوارث والطقس"))
            box.addView(onboarding(), lp(MATCH, WRAP, t = 12))
            return
        }
        val rep = AppState.reports[city.key]
        val wx = AppState.weather[city.key]
        val level = rep?.overall() ?: 0
        val tone = if (rep == null) Ui.ACCENT else Ui.levelColor(level)

        // ---- الترويسة ----
        val head = row()
        val names = col().apply {
            addView(tv("حارس الأرض", 12f, Ui.ACCENT, true))
            val cr = row()
            cr.addView(icon(R.drawable.ic_nav_city, 22, Ui.ACCENT))
            cr.addView(tv(city.name, 26f, Ui.TEXT, true), lp(WRAP, WRAP, s = 6))
            addView(cr)
            val sub = if (city.gps) "حسب موقعك الحالي" + (if (city.country.isNotBlank()) " • ${city.country}" else "") else city.country
            addView(tv(sub, 12f, Ui.DIM))
            setOnClickListener { selectTab(3) }
        }
        head.addView(names, lp(0, WRAP, weight = 1f))
        val refresh = badge(R.drawable.ic_refresh, if (loading) Ui.DIM else Ui.ACCENT, 44)
        refresh.setOnClickListener { refreshAll() }
        if (loading) {
            refresh.startAnimation(RotateAnimation(
                0f, 360f, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f
            ).apply {
                duration = 900
                repeatCount = Animation.INFINITE
                interpolator = LinearInterpolator()
            })
        }
        head.addView(refresh)
        box.addView(head)

        // ---- بطاقة الحالة والطقس ----
        val hero = card(16)
        val top = row()
        val info = col()
        if (wx != null) {
            val n = wx.now
            info.addView(tv(tmp(n.temp), 52f, Ui.TEXT, true))
            val d = row()
            d.addView(icon(Wx.icon(n.code, n.isDay), 22, Wx.color(n.code)))
            d.addView(tv(Wx.desc(n.code), 16f, Ui.TEXT), lp(WRAP, WRAP, s = 8))
            info.addView(d)
            val today = wx.days.firstOrNull()
            val range = if (today != null) " • العظمى ${tmp(today.tMax)} • الصغرى ${tmp(today.tMin)}" else ""
            info.addView(tv("تبدو كأنها ${tmp(n.feels)}$range", 12f, Ui.DIM), lp(WRAP, WRAP, t = 4))
        } else {
            info.addView(tv(if (loading) "جارٍ تحميل الطقس…" else "تعذّر تحميل الطقس", 16f, Ui.DIM))
        }
        top.addView(info, lp(0, WRAP, weight = 1f))
        val radar = RadarView(this).apply {
            this.tone = tone
            blips = rep?.alerts?.map { (it.id.hashCode() and 0x7fffffff) % 360 } ?: emptyList()
        }
        top.addView(radar, lp(dp(116), dp(116)))
        hero.addView(top)

        val statusText = when {
            rep == null -> if (loading) "⏳ جارٍ جمع البيانات من الأقمار والمحطات…" else "لا توجد بيانات بعد"
            rep.allFailed() -> "❌ تعذّر الاتصال بمصادر البيانات"
            level == 0 -> "✅ الوضع آمن في ${city.name}"
            level == 1 -> "🟠 ترقّب: توجد إنذارات مبكرة"
            else -> "🔴 خطر: توجد أحداث نشطة"
        }
        val pill = tv(statusText, 14f, tone, true).apply {
            setPadding(dp(14), dp(10), dp(14), dp(10))
            background = shape(Ui.withAlpha(tone, 32), 14)
        }
        hero.addView(pill, lp(MATCH, WRAP, t = 12))
        if (rep != null && rep.failed.isNotEmpty() && !rep.allFailed()) {
            hero.addView(tv("تعذّر الوصول إلى: " + rep.failed.joinToString("، "), 11f, Ui.DIM), lp(WRAP, WRAP, t = 6))
        }
        if (rep != null) {
            hero.addView(tv("آخر تحديث: ${ago(rep.time)}", 11f, Ui.DIM), lp(WRAP, WRAP, t = 6))
        }
        box.addView(hero, lp(MATCH, WRAP, t = 12))

        // ---- مؤشرات سريعة ----
        if (wx != null) {
            val stats = row()
            stats.addView(stat(R.drawable.ic_h_flood, "${wx.now.humidity}%", "الرطوبة"), lp(0, WRAP, weight = 1f))
            stats.addView(stat(R.drawable.ic_wind, "${wx.now.wind.roundToInt()} كم/س", "الرياح"), lp(0, WRAP, s = 8, weight = 1f))
            stats.addView(stat(R.drawable.ic_gauge, "${wx.now.pressure.roundToInt()}", "الضغط hPa"), lp(0, WRAP, s = 8, weight = 1f))
            box.addView(stats, lp(MATCH, WRAP, t = 12))
        }

        // ---- رادار المخاطر ----
        val grid = card(16)
        grid.addView(tv("رادار المخاطر", 17f, Ui.TEXT, true))
        grid.addView(tv("اضغط على أي خطر لعرض تفاصيله", 12f, Ui.DIM), lp(WRAP, WRAP, b = 10))
        val hz = Hazard.values().toList()
        for (rowItems in hz.chunked(3)) {
            val r = row()
            rowItems.forEachIndexed { idx, h ->
                val lv = rep?.level(h) ?: 0
                val color = if (rep == null) Ui.DIM else Ui.levelColor(lv)
                val cell = col(8).apply {
                    gravity = Gravity.CENTER_HORIZONTAL
                    addView(badge(h.icon, color, 46))
                    addView(tv(h.short, 13f, Ui.TEXT, true, center = true), lp(MATCH, WRAP, t = 6))
                    addView(tv(if (rep == null) "—" else Ui.levelText(lv), 12f, color, true, center = true), lp(MATCH, WRAP))
                    setOnClickListener { filter = h; selectTab(1) }
                }
                r.addView(cell, lp(0, WRAP, s = if (idx == 0) 0 else 6, weight = 1f))
            }
            grid.addView(r, lp(MATCH, WRAP, t = 6))
        }
        box.addView(grid, lp(MATCH, WRAP, t = 12))

        // ---- أبرز التنبيهات ----
        val alerts = (rep?.alerts ?: emptyList()).sortedBy { if (it.forecast) 1 else 0 }
        if (alerts.isNotEmpty()) {
            box.addView(tv("أبرز التنبيهات", 17f, Ui.TEXT, true), lp(WRAP, WRAP, t = 16, b = 8))
            alerts.take(3).forEach { box.addView(alertCard(it, null), lp(MATCH, WRAP, b = 10)) }
            if (alerts.size > 3) {
                box.addView(button("عرض كل التنبيهات (${alerts.size})", false) { filter = null; selectTab(1) })
            }
        }

        // ---- 24 ساعة ----
        if (wx != null) {
            val ch = card(16)
            ch.addView(tv("الحرارة خلال 24 ساعة", 17f, Ui.TEXT, true))
            val chart = HourlyChart(this).apply {
                temps = wx.hourTemps.map { conv(it) }
                startHour = wx.startHour
            }
            ch.addView(chart, lp(MATCH, dp(170), t = 6))
            box.addView(ch, lp(MATCH, WRAP, t = 16))

            val dc = card(16)
            dc.addView(tv("توقعات 7 أيام", 17f, Ui.TEXT, true), lp(WRAP, WRAP, b = 6))
            wx.days.forEachIndexed { i, d ->
                val r = row().apply { setPadding(0, dp(8), 0, dp(8)) }
                r.addView(tv(Weather.dayName(d.date, i), 15f, Ui.TEXT, i == 0), lp(0, WRAP, weight = 1.2f))
                r.addView(icon(Wx.icon(d.code, true), 24, Wx.color(d.code)))
                r.addView(tv(if (d.rain >= 1) "${d.rain.roundToInt()} مم" else "", 12f, Ui.ACCENT), lp(dp(56), WRAP, s = 8))
                r.addView(tv(tmp(d.tMax), 15f, Ui.TEXT, true), lp(dp(54), WRAP))
                r.addView(tv(tmp(d.tMin), 15f, Ui.DIM), lp(dp(54), WRAP))
                dc.addView(r)
            }
            box.addView(dc, lp(MATCH, WRAP, t = 12))
        }

        box.addView(
            tv("«التوقعات» مبنية على اتجاهات الطقس والنشاط الزلزالي وهي احتمالية، ولا يمكن التنبؤ بموعد الزلازل. التطبيق مساعد إضافي ولا يغني عن التحذيرات الرسمية.", 11f, Ui.DIM),
            lp(MATCH, WRAP, t = 16, b = 8)
        )
    }

    private fun stat(res: Int, value: String, label: String): LinearLayout = col(12).apply {
        background = shape(Ui.SURFACE, 16, Ui.STROKE)
        gravity = Gravity.CENTER_HORIZONTAL
        addView(icon(res, 20, Ui.ACCENT))
        addView(tv(value, 15f, Ui.TEXT, true, center = true), lp(WRAP, WRAP, t = 4))
        addView(tv(label, 11f, Ui.DIM, center = true))
    }

    private fun onboarding(): LinearLayout {
        val c = card(20)
        c.gravity = Gravity.CENTER_HORIZONTAL
        val radar = RadarView(this).apply { tone = Ui.ACCENT }
        c.addView(radar, lp(dp(150), dp(150)))
        c.addView(tv("حارس الأرض", 24f, Ui.TEXT, true), lp(WRAP, WRAP, t = 12))
        c.addView(
            tv("يراقب الزلازل والعواصف والفيضانات والبراكين والحر والبرد في مدينتك، عبر بيانات الأقمار الصناعية ومراكز الرصد، وينبّهك قبل أن يتفاقم الخطر.", 14f, Ui.DIM).apply { gravity = Gravity.CENTER },
            lp(MATCH, WRAP, t = 8, b = 16)
        )
        c.addView(button("📍 استخدم موقعي الحالي", true) { useMyLocation() }, lp(MATCH, WRAP))
        c.addView(button("🔎 اختر مدينة", false) { selectTab(3) }, lp(MATCH, WRAP, t = 10))
        return c
    }

    // ======================= التنبيهات =======================

    private fun alertCard(a: Alert, cityName: String?): LinearLayout {
        val tone = if (a.forecast) Ui.WATCH else Ui.DANGER
        val r = row().apply {
            gravity = Gravity.TOP
            setPadding(dp(14), dp(14), dp(14), dp(14))
            background = shape(Ui.SURFACE, 18, Ui.withAlpha(tone, 120))
        }
        r.addView(badge(a.hazard.icon, tone, 44))
        val c = col().apply {
            addView(tv(a.title, 16f, Ui.TEXT, true))
            addView(tv(a.body, 13f, Ui.DIM), lp(MATCH, WRAP, t = 4, b = 8))
            val tags = row()
            tags.addView(tag(if (a.forecast) "توقع" else "حدث", tone))
            if (a.official) tags.addView(tag("رسمي", Ui.ACCENT))
            if (cityName != null) tags.addView(tag(cityName, Ui.DIM))
            addView(tags)
        }
        r.addView(c, lp(0, WRAP, s = 12, weight = 1f))
        return r
    }

    private fun renderAlerts() {
        val box = screen()
        box.addView(titleBar("التنبيهات", "أحداث فعلية وتوقعات مبنية على التغيّرات"))

        val hs = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val chips = row()
        fun chip(label: String, h: Hazard?) {
            val sel = filter == h
            chips.addView(
                tv(label, 13f, if (sel) Ui.BG else Ui.TEXT, true).apply {
                    setPadding(dp(14), dp(8), dp(14), dp(8))
                    background = if (sel) shape(Ui.ACCENT, 18) else shape(Ui.SURFACE, 18, Ui.STROKE)
                    setOnClickListener { filter = h; render() }
                },
                lp(WRAP, WRAP, e = 8)
            )
        }
        chip("الكل", null)
        Hazard.values().forEach { chip(it.short, it) }
        hs.addView(chips)
        box.addView(hs, lp(MATCH, WRAP, t = 8, b = 12))

        val cities = Store.all(this)
        val items = cities.flatMap { c ->
            (AppState.reports[c.key]?.alerts ?: emptyList()).map { c to it }
        }.filter { filter == null || it.second.hazard == filter }
            .sortedBy { if (it.second.forecast) 1 else 0 }

        if (items.isEmpty()) {
            val msg = when {
                cities.isEmpty() -> "أضف مدينة أولاً من تبويب «المدن»."
                loading -> "⏳ جارٍ الفحص…"
                else -> "✅ لا توجد تنبيهات" + (if (filter != null) " في هذا القسم" else "") + " حالياً.\nالمراقبة تعمل في الخلفية كل 15 دقيقة."
            }
            box.addView(
                card(20).apply { addView(tv(msg, 15f, Ui.DIM).apply { gravity = Gravity.CENTER }) },
                lp(MATCH, WRAP)
            )
        } else {
            items.forEach { (c, a) ->
                box.addView(alertCard(a, c.name), lp(MATCH, WRAP, b = 10))
            }
        }
    }

    // ======================= الأقمار الصناعية =======================

    @SuppressLint("SetJavaScriptEnabled")
    private fun webView(): WebView = web ?: WebView(this).also { w ->
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.webViewClient = WebViewClient()
        w.setBackgroundColor(Ui.BG)
        web = w
    }

    private fun renderSat() {
        val city = Store.selected(this)
        val box = col(16)
        box.addView(titleBar("الأقمار الصناعية", if (city != null) "أمطار وسحب فوق ${city.name} (NASA GIBS)" else "اختر مدينة أولاً"))
        if (city == null) {
            box.addView(button("اختر مدينة", true) { selectTab(3) })
        } else {
            val w = webView()
            if (webKey != city.key) {
                w.loadUrl("file:///android_asset/map.html?lat=${city.lat}&lon=${city.lon}")
                webKey = city.key
            }
            (w.parent as? android.view.ViewGroup)?.removeView(w)
            box.addView(w, lp(MATCH, 0, weight = 1f))
        }
        content.addView(box, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    // ======================= المدن =======================

    private fun renderCities() {
        val box = screen()
        box.addView(titleBar("مدني", "اختر المدن التي تريد مراقبتها"))

        // بحث
        val sr = row().apply {
            background = shape(Ui.SURFACE, 16, Ui.STROKE)
            setPadding(dp(12), 0, dp(8), 0)
        }
        val et = EditText(this).apply {
            hint = "ابحث عن مدينة (مثل: Miami أو القاهرة)"
            setHintTextColor(Ui.DIM)
            setTextColor(Ui.TEXT)
            textSize = 15f
            background = null
            isSingleLine = true
            inputType = InputType.TYPE_CLASS_TEXT
            imeOptions = EditorInfo.IME_ACTION_SEARCH
            setText(query)
            doAfterTextChanged { query = it?.toString() ?: "" }
            setOnEditorActionListener { v, id, _ ->
                if (id == EditorInfo.IME_ACTION_SEARCH) {
                    searchCity(v.text.toString())
                    true
                } else false
            }
        }
        sr.addView(icon(R.drawable.ic_search, 22, Ui.ACCENT).apply {
            setOnClickListener { searchCity(et.text.toString()) }
        })
        sr.addView(et, lp(0, dp(50), s = 8, weight = 1f))
        box.addView(sr, lp(MATCH, WRAP, t = 8))

        resultsBox = col()
        box.addView(resultsBox, lp(MATCH, WRAP))
        fillResults()

        box.addView(button("📍 استخدم موقعي الحالي (GPS)", true) { useMyLocation() }, lp(MATCH, WRAP, t = 10))

        // المدن المحفوظة
        val all = Store.all(this)
        val sel = Store.selected(this)
        box.addView(tv("المدن المراقَبة (${all.size})", 17f, Ui.TEXT, true), lp(WRAP, WRAP, t = 18, b = 8))
        if (all.isEmpty()) {
            box.addView(tv("لا توجد مدن بعد. ابحث عن مدينة أو اختر من القائمة أدناه.", 13f, Ui.DIM))
        }
        all.forEach { c ->
            val rep = AppState.reports[c.key]
            val color = if (rep == null) Ui.DIM else Ui.levelColor(rep.overall())
            val r = row().apply {
                setPadding(dp(14), dp(12), dp(8), dp(12))
                background = shape(Ui.SURFACE, 16, if (sel?.key == c.key) Ui.ACCENT else Ui.STROKE)
                setOnClickListener { selectCity(c) }
            }
            r.addView(badge(if (c.gps) R.drawable.ic_gps else R.drawable.ic_nav_city, color, 40))
            val names = col().apply {
                addView(tv(c.name, 16f, Ui.TEXT, true))
                val sub = (if (c.gps) "موقعك الحالي" + (if (c.country.isNotBlank()) " • ${c.country}" else "") else c.country) +
                    (if (rep != null) " • " + Ui.levelText(rep.overall()) else "")
                addView(tv(sub, 12f, Ui.DIM))
            }
            r.addView(names, lp(0, WRAP, s = 12, weight = 1f))
            r.addView(icon(R.drawable.ic_close, 36, Ui.DIM).apply {
                setPadding(dp(8), dp(8), dp(8), dp(8))
                setOnClickListener { removeCity(c) }
            })
            box.addView(r, lp(MATCH, WRAP, b = 8))
        }

        // مدن شائعة
        box.addView(tv("مدن شائعة", 17f, Ui.TEXT, true), lp(WRAP, WRAP, t = 18, b = 8))
        for (group in Popular.cities.chunked(3)) {
            val r = row()
            group.forEachIndexed { idx, c ->
                r.addView(
                    tv(c.name, 13f, Ui.TEXT).apply {
                        gravity = Gravity.CENTER
                        setPadding(dp(6), dp(10), dp(6), dp(10))
                        background = shape(Ui.SURFACE, 14, Ui.STROKE)
                        setOnClickListener { addCity(c) }
                    },
                    lp(0, WRAP, s = if (idx == 0) 0 else 8, weight = 1f)
                )
            }
            box.addView(r, lp(MATCH, WRAP, b = 8))
        }

        // الإعدادات
        val st = card(16)
        st.addView(tv("الإعدادات", 15f, Ui.TEXT, true), lp(WRAP, WRAP, b = 4))
        fun sw(label: String, on: Boolean, onChange: (Boolean) -> Unit) {
            st.addView(Switch(this).apply {
                text = label
                textSize = 14f
                setTextColor(Ui.TEXT)
                isChecked = on
                setPadding(0, dp(10), 0, dp(10))
                setOnCheckedChangeListener { _, v -> onChange(v) }
            }, lp(MATCH, WRAP))
        }
        sw("إشعارات التوقعات المبكرة (غير الأحداث الفعلية)", Store.forecastNotifs(this)) { Store.setForecastNotifs(this, it) }
        sw("عرض الحرارة بالفهرنهايت °F", Store.useF(this)) { Store.setUseF(this, it) }
        box.addView(st, lp(MATCH, WRAP, t = 18))

        // عن التطبيق
        val about = card(16)
        about.addView(tv("عن حارس الأرض", 15f, Ui.TEXT, true))
        about.addView(
            tv("المصادر: USGS (زلازل) • Open-Meteo (طقس ومناخ وفيضانات) • NASA EONET وNASA GIBS (أقمار صناعية) • NWS (تحذيرات أمريكا الرسمية) • GDACS (أعاصير وفيضانات وبراكين عالمياً).\nمواقعك ومدنك تُحفظ على جهازك فقط ولا نملك خادماً.", 12f, Ui.DIM),
            lp(MATCH, WRAP, t = 6)
        )
        box.addView(about, lp(MATCH, WRAP, t = 12, b = 8))
    }

    private fun fillResults() {
        val b = resultsBox ?: return
        b.removeAllViews()
        searchMsg?.let { b.addView(tv(it, 13f, Ui.DIM), lp(WRAP, WRAP, t = 8, b = 4)) }
        searchResults.forEach { c ->
            val r = row().apply {
                setPadding(dp(14), dp(12), dp(14), dp(12))
                background = shape(Ui.SURFACE2, 16, Ui.STROKE)
                setOnClickListener { addCity(c) }
            }
            r.addView(icon(R.drawable.ic_nav_city, 22, Ui.ACCENT))
            val names = col().apply {
                addView(tv(c.name, 15f, Ui.TEXT, true))
                addView(tv(c.country, 12f, Ui.DIM))
            }
            r.addView(names, lp(0, WRAP, s = 10, weight = 1f))
            r.addView(tv("+ إضافة", 13f, Ui.ACCENT, true))
            b.addView(r, lp(MATCH, WRAP, t = 8))
        }
    }

    private fun searchCity(q: String) {
        if (q.isBlank()) return
        searchMsg = "جارٍ البحث…"
        searchResults = emptyList()
        fillResults()
        thread {
            val list = try { Geo.search(q) } catch (e: Exception) { null }
            runOnUiThread {
                if (isFinishing) return@runOnUiThread
                searchResults = list ?: emptyList()
                searchMsg = when {
                    list == null -> "تعذّر البحث، تحقق من الإنترنت."
                    list.isEmpty() -> "لا توجد نتائج."
                    else -> null
                }
                fillResults()
            }
        }
    }

    private fun addCity(c: City) {
        if (!Store.add(this, c)) {
            toast("الحد الأقصى ${Store.MAX_SAVED} مدن. احذف مدينة أولاً.")
            return
        }
        searchResults = emptyList()
        searchMsg = null
        selectCity(c)
    }

    private fun removeCity(c: City) {
        Store.remove(this, c)
        AppState.reports.remove(c.key)
        AppState.weather.remove(c.key)
        render()
    }

    private fun selectCity(c: City) {
        Store.setSelected(this, c)
        filter = null
        tab = 0
        updateNav()
        render()
        val rep = AppState.reports[c.key]
        val stale = rep == null || System.currentTimeMillis() - rep.time > 10 * 60 * 1000 || AppState.weather[c.key] == null
        if (stale) refreshAll()
    }

    // ======================= جلب البيانات =======================

    private fun refreshAll() {
        if (loading) {
            pendingRefresh = true
            return
        }
        val sel = Store.selected(this)
        val cities = Store.all(this).sortedBy { if (it.key == sel?.key) 0 else 1 }
        if (cities.isEmpty()) return
        loading = true
        render(true)
        thread {
            for ((i, c) in cities.withIndex()) {
                val rep = try {
                    Checker.check(this, c)
                } catch (e: Exception) {
                    Report(c, emptyList(), listOf("كل المصادر"), 1)
                }
                val wx = try { Weather.fetch(c.lat, c.lon) } catch (e: Exception) { null }
                runCatching { Notifier.notifyNew(this, c, rep.alerts) }
                runOnUiThread {
                    AppState.reports[c.key] = rep
                    if (wx != null) AppState.weather[c.key] = wx
                    if (!isFinishing && i == 0 && tab != 3) render(true)
                }
            }
            runOnUiThread {
                loading = false
                lastRefresh = System.currentTimeMillis()
                if (!isFinishing) {
                    if (pendingRefresh) {
                        pendingRefresh = false
                        refreshAll()
                    } else {
                        render(true)
                    }
                }
            }
        }
    }

    // ======================= الموقع =======================

    private fun useMyLocation() {
        val has = listOf(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION)
            .any { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }
        if (!has) {
            wantGps = true
            requestPermissions(
                arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION), 1
            )
            return
        }
        locate()
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        if (code != 1) return
        val ok = results.any { it == PackageManager.PERMISSION_GRANTED }
        if (ok && wantGps) locate() else if (!ok) toast("بدون إذن الموقع يمكنك اختيار مدينة يدوياً من تبويب «المدن».")
        wantGps = false
    }

    @Suppress("MissingPermission", "DEPRECATION")
    private fun locate() {
        toast("جارٍ تحديد موقعك…")
        val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val providers = lm.getProviders(true).filter { it != LocationManager.PASSIVE_PROVIDER }
        val last = providers
            .mapNotNull { runCatching { lm.getLastKnownLocation(it) }.getOrNull() }
            .maxByOrNull { it.time }
        if (last != null) {
            onLocation(last)
            return
        }
        val provider = providers.firstOrNull { it == LocationManager.NETWORK_PROVIDER } ?: providers.firstOrNull()
        if (provider == null) {
            toast("فعّل خدمة الموقع (GPS) ثم أعد المحاولة، أو اختر مدينة يدوياً.")
            return
        }
        var done = false
        val listener = object : LocationListener {
            override fun onLocationChanged(loc: Location) {
                done = true
                lm.removeUpdates(this)
                onLocation(loc)
            }
            override fun onProviderEnabled(p: String) {}
            override fun onProviderDisabled(p: String) {}
            @Deprecated("old API")
            override fun onStatusChanged(p: String?, s: Int, e: Bundle?) {}
        }
        lm.requestLocationUpdates(provider, 0L, 0f, listener, Looper.getMainLooper())
        Handler(Looper.getMainLooper()).postDelayed({
            if (!done) {
                lm.removeUpdates(listener)
                toast("تعذّر تحديد موقعك. اخرج لمكان مفتوح أو اختر مدينة يدوياً من تبويب «المدن».")
            }
        }, 25000)
    }

    private fun onLocation(loc: Location) {
        Store.setGps(this, loc.latitude, loc.longitude)
        nameLocation(loc.latitude, loc.longitude)
        Store.gps(this)?.let { Store.setSelected(this, it) }
        filter = null
        tab = 0
        updateNav()
        render()
        refreshAll()
    }

    /** يحوّل الإحداثيات إلى اسم مدينة (إن توفرت خدمة Geocoder في الجهاز)، وإلا يبقى «موقعي الحالي». */
    @Suppress("DEPRECATION")
    private fun nameLocation(lat: Double, lon: Double) {
        thread {
            try {
                if (!android.location.Geocoder.isPresent()) return@thread
                val g = android.location.Geocoder(this, java.util.Locale("ar"))
                val a = g.getFromLocation(lat, lon, 1)?.firstOrNull() ?: return@thread
                val name = a.locality ?: a.subAdminArea ?: a.adminArea ?: return@thread
                Store.setGpsName(this, name, a.countryName ?: "")
                runOnUiThread { if (!isFinishing) render(true) }
            } catch (_: Exception) {
            }
        }
    }
}
