package com.example.disasteralert

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.Looper
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlin.concurrent.thread

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var list: LinearLayout

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = dp(16)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        root.addView(TextView(this).apply {
            text = "⚠️ تنبيه الكوارث"
            textSize = 26f
            setTextColor(Color.parseColor("#B71C1C"))
            gravity = Gravity.CENTER
        })
        status = TextView(this).apply {
            textSize = 15f
            setPadding(0, pad, 0, pad)
            text = "اضغط «افحص الآن» لبدء المراقبة."
        }
        root.addView(status)
        root.addView(Button(this).apply {
            text = "افحص الآن"
            setOnClickListener { requestAndCheck() }
        })
        root.addView(Button(this).apply {
            text = "🛰️ خريطة الأقمار الصناعية (أمطار وسحب)"
            setOnClickListener { startActivity(Intent(this@MainActivity, MapActivity::class.java)) }
        })
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(list)
        root.addView(TextView(this).apply {
            textSize = 12f
            setPadding(0, pad, 0, 0)
            text = "المصادر: USGS (زلازل) • Open-Meteo (طقس ومناخ وفيضانات) • NASA EONET (براكين وعواصف، من رصد الأقمار الصناعية) • NASA GIBS (صور الأقمار الصناعية).\n" +
                "يُستخدم موقعك لجلب البيانات القريبة منك فقط، ويُحفظ على جهازك ولا نملك خادماً.\n" +
                "«التوقعات» مبنية على اتجاهات الطقس والنشاط الزلزالي وهي احتمالية وليست مؤكدة؛ ولا يمكن التنبؤ بموعد الزلازل. " +
                "التطبيق مساعد إضافي ولا يغني عن التحذيرات الرسمية."
        })

        val scroll = ScrollView(this).apply { addView(root) }
        setContentView(scroll)
        Edge.apply(scroll)

        Notifier.ensureChannel(this)
        MonitorWorker.schedule(this)
        requestAndCheck()
    }

    private fun requestAndCheck() {
        val perms = mutableListOf(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION)
        if (Build.VERSION.SDK_INT >= 33) perms += Manifest.permission.POST_NOTIFICATIONS
        val missing = perms.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) {
            requestPermissions(missing.toTypedArray(), 1)
        } else {
            locateAndCheck()
        }
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        val ok = checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (ok) locateAndCheck() else status.text = "التطبيق يحتاج إذن الموقع لتحديد الكوارث القريبة منك."
    }

    @Suppress("MissingPermission", "DEPRECATION")
    private fun locateAndCheck() {
        status.text = "جارٍ تحديد موقعك…"
        val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        // نستثني المزوّد "passive" لأنه لا يعطي موقعاً بنفسه
        val providers = lm.getProviders(true).filter { it != LocationManager.PASSIVE_PROVIDER }
        val last = providers
            .mapNotNull { runCatching { lm.getLastKnownLocation(it) }.getOrNull() }
            .maxByOrNull { it.time }
        if (last != null) {
            runCheck(last)
            return
        }
        val provider = providers.firstOrNull { it == LocationManager.NETWORK_PROVIDER } ?: providers.firstOrNull()
        if (provider == null) {
            status.text = "فعّل خدمة الموقع (GPS) ثم أعد المحاولة."
            return
        }
        lm.requestLocationUpdates(provider, 0L, 0f, object : LocationListener {
            override fun onLocationChanged(loc: Location) {
                lm.removeUpdates(this)
                runCheck(loc)
            }
            override fun onProviderEnabled(p: String) {}
            override fun onProviderDisabled(p: String) {}
            @Deprecated("old API")
            override fun onStatusChanged(p: String?, s: Int, e: Bundle?) {}
        }, Looper.getMainLooper())
    }

    private fun runCheck(loc: Location) {
        getSharedPreferences("prefs", Context.MODE_PRIVATE).edit()
            .putLong("lat", java.lang.Double.doubleToLongBits(loc.latitude))
            .putLong("lon", java.lang.Double.doubleToLongBits(loc.longitude))
            .apply()
        status.text = "جارٍ فحص البيانات…"
        thread {
            val rep = try {
                Checker.check(this, loc.latitude, loc.longitude)
            } catch (e: Exception) {
                Report(emptyList(), List(Checker.sourceCount()) { "مصدر" })
            }
            Notifier.notifyNew(this, rep.alerts)
            runOnUiThread { show(rep) }
        }
    }

    private fun show(rep: Report) {
        list.removeAllViews()
        val events = rep.alerts.filter { !it.forecast }
        val forecasts = rep.alerts.filter { it.forecast }
        val allFailed = rep.failed.size >= Checker.sourceCount()

        status.text = when {
            allFailed -> "❌ تعذّر الاتصال بمصادر البيانات. تحقق من الإنترنت ثم أعد المحاولة."
            rep.alerts.isEmpty() -> "✅ لا توجد تنبيهات خطرة حالياً في منطقتك.\n(المراقبة تعمل في الخلفية كل 15 دقيقة)" +
                (if (rep.failed.isNotEmpty()) "\n⚠️ تعذّر الوصول إلى: " + rep.failed.joinToString("، ") else "")
            else -> "⚠️ أحداث: ${events.size} • توقعات: ${forecasts.size}" +
                (if (rep.failed.isNotEmpty()) "\n⚠️ تعذّر الوصول إلى: " + rep.failed.joinToString("، ") else "")
        }
        addSection("🔴 أحداث حالية", events, "#FFEBEE")
        addSection("🟠 توقعات وإنذارات مبكرة (مبنية على اتجاهات التغيّر)", forecasts, "#FFF3E0")
    }

    private fun addSection(title: String, items: List<Alert>, bg: String) {
        if (items.isEmpty()) return
        list.addView(TextView(this).apply {
            text = title
            textSize = 17f
            setPadding(0, dp(12), 0, dp(6))
        })
        items.forEach { a ->
            list.addView(TextView(this).apply {
                text = "${a.title}\n${a.body}"
                textSize = 15f
                setPadding(dp(12), dp(12), dp(12), dp(12))
                setBackgroundColor(Color.parseColor(bg))
                val lp = LinearLayout.LayoutParams(-1, -2)
                lp.setMargins(0, 0, 0, dp(6))
                layoutParams = lp
            })
        }
    }
}
