package com.example.disasteralert

import android.content.Context
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import java.util.concurrent.TimeUnit

/** يعمل في الخلفية كل 15 دقيقة (أقل فترة يسمح بها أندرويد) ويفحص الموقع المحفوظ. */
class MonitorWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {

    override suspend fun doWork(): Result {
        val prefs = applicationContext.getSharedPreferences("prefs", Context.MODE_PRIVATE)
        if (!prefs.contains("lat")) return Result.success()
        val lat = java.lang.Double.longBitsToDouble(prefs.getLong("lat", 0))
        val lon = java.lang.Double.longBitsToDouble(prefs.getLong("lon", 0))
        return try {
            val r = Checker.check(applicationContext, lat, lon)
            Notifier.notifyNew(applicationContext, r.alerts)
            // إن فشلت كل المصادر (لا إنترنت) نعيد المحاولة لاحقاً
            if (r.failed.size >= Checker.sourceCount()) Result.retry() else Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }

    companion object {
        fun schedule(ctx: Context) {
            val req = PeriodicWorkRequestBuilder<MonitorWorker>(15, TimeUnit.MINUTES)
                .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
                .build()
            WorkManager.getInstance(ctx)
                .enqueueUniquePeriodicWork("monitor", ExistingPeriodicWorkPolicy.UPDATE, req)
        }
    }
}
