package com.example.disasteralert

import android.content.Context
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import java.util.concurrent.TimeUnit

/** يعمل في الخلفية كل 15 دقيقة (أقل فترة يسمح بها أندرويد) ويفحص كل المدن المحفوظة. */
class MonitorWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {

    override suspend fun doWork(): Result {
        val cities = Store.all(applicationContext)
        if (cities.isEmpty()) return Result.success()
        var failedCities = 0
        for (city in cities) {
            try {
                val r = Checker.check(applicationContext, city)
                Notifier.notifyNew(applicationContext, city, r.alerts)
                if (r.allFailed()) failedCities++
            } catch (e: Exception) {
                failedCities++
            }
        }
        // إن فشلت كل المدن (لا إنترنت) نعيد المحاولة لاحقاً
        return if (failedCities == cities.size) Result.retry() else Result.success()
    }

    companion object {
        fun schedule(ctx: Context) {
            val req = PeriodicWorkRequestBuilder<MonitorWorker>(15, TimeUnit.MINUTES)
                .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
                .build()
            WorkManager.getInstance(ctx)
                .enqueueUniquePeriodicWork("monitor", ExistingPeriodicWorkPolicy.UPDATE, req)
        }
    }
}
