plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// بيانات التوقيع تأتي من متغيرات البيئة (GitHub Secrets) ولا تُحفظ في الكود أبداً
val ksPath: String? = System.getenv("KEYSTORE_PATH")
val hasSigning = !ksPath.isNullOrBlank() && file(ksPath).exists()

android {
    namespace = "com.example.disasteralert"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.example.disasteralert" // غيّره إلى معرّف فريد خاص بك قبل أول نشر
        minSdk = 24
        targetSdk = 36
        versionCode = (System.getenv("VERSION_CODE") ?: "1").toInt()
        versionName = "1.0.${System.getenv("VERSION_CODE") ?: "1"}"
    }

    signingConfigs {
        if (hasSigning) {
            create("release") {
                storeFile = file(ksPath!!)
                storePassword = System.getenv("KEYSTORE_PASSWORD")
                keyAlias = System.getenv("KEY_ALIAS")
                keyPassword = System.getenv("KEY_PASSWORD")
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            if (hasSigning) signingConfig = signingConfigs.getByName("release")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    lint {
        abortOnError = false
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.work:work-runtime-ktx:2.9.1")
}
