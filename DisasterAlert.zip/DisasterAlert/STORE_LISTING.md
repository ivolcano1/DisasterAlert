# Google Play listing

## العربية
**الاسم (30):** حارس الأرض
**وصف قصير (80):** تنبيهات الزلازل والعواصف والفيضانات والطقس القاسي لمدينتك مع صور الأقمار.
**الوصف الكامل:**
حارس الأرض يراقب الطقس والنشاط الزلزالي والبراكين في مدنك ويُنبّهك عند الخطر.
• تنبيهات فعلية: زلازل، فيضانات، براكين، عواصف، حر وبرد شديدان
• إنذارات مبكرة مبنية على اتجاهات الطقس (احتمالية)
• تحذيرات رسمية من هيئة الأرصاد الأمريكية للمدن الأمريكية
• خريطة أقمار صناعية للأمطار والسحب (NASA)
• عدة مدن + موقعك الحالي، توقعات 7 أيام و24 ساعة
• دليل سلامة وأرقام طوارئ لكل خطر
• يعمل دون إنترنت بعرض آخر بيانات محفوظة
• عربي وإنجليزي، بلا إعلانات ولا تتبع
تنبيه: تطبيق غير رسمي لا يمثل جهة حكومية ولا يغني عن التحذيرات الرسمية. لا يمكن التنبؤ بموعد الزلازل.

## English
**Name (30):** Earth Guardian
**Short (80):** Earthquake, storm, flood & extreme-weather alerts for your city with satellite maps.
**Full description:**
Earth Guardian watches weather, seismic activity and volcanoes in your cities and alerts you when danger appears.
• Live alerts: earthquakes, floods, volcanoes, storms, extreme heat and cold
• Early warnings from weather trends (probabilistic)
• Official US NWS warnings for US cities
• NASA satellite map of rain and clouds
• Multiple cities + current location, 7-day and 24-hour forecasts
• Safety guide and emergency numbers per hazard
• Works offline with the last saved data
• Arabic and English, no ads, no tracking
Disclaimer: Unofficial app; not affiliated with any government body and not a substitute for official warnings. Earthquakes cannot be predicted.

## Data safety (summary)
- Location: approximate/precise, optional, processed on device; coordinates of the chosen city are sent to public weather/hazard APIs to provide the service; not sold; no ads.
- No account, no analytics, no data stored on our servers.
- Notifications permission: disaster alerts only.
- Category: Weather (or Tools). Audience: 18+. Add privacy policy URL and contact email.
