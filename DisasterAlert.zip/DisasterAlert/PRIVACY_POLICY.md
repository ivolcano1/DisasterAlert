# سياسة الخصوصية — حارس الأرض

آخر تحديث: 2026-11-27

**ما نجمعه:** يستخدم التطبيق موقعك التقريبي (بإذنك) أو المدن التي تختارها لعرض الطقس وتحديد الأخطار القريبة. يُحفظ الموقع وقائمة المدن على جهازك فقط.

**مع من نشاركه:** لا نملك خادماً ولا نجمع بياناتك. عند الفحص تُرسَل إحداثيات المدينة (وليس هويتك) إلى الخدمات العامة التالية للحصول على البيانات:
- Open-Meteo: الطقس والمناخ والفيضانات، والبحث عن اسم مدينة تكتبه.
- هيئة الأرصاد الأمريكية NWS: تحذيرات رسمية، فقط للمدن داخل الولايات المتحدة.
- USGS (زلازل) وNASA EONET (براكين وعواصف) وGDACS (أعاصير مدارية): تُجلب كقوائم عامة دون إرسال موقعك.
- NASA GIBS وOpenStreetMap: صور الأقمار الصناعية والخرائط داخل شاشة الأقمار.
تصل هذه الخدمات عنوان IP الخاص بجهازك كأي اتصال إنترنت.

**الإشعارات:** تُستخدم لإرسال تنبيهات الكوارث فقط.

**الإعلانات والتحليلات:** لا يحتوي التطبيق على إعلانات أو أدوات تتبع.

**الحذف:** احذف مدينة من تبويب «المدن» أو احذف التطبيق لإزالة كل البيانات المحفوظة على جهازك.

**إخلاء مسؤولية:** التطبيق مساعد إضافي ولا يغني عن تحذيرات الجهات الرسمية، ولا نضمن دقة أو توقيت البيانات. التوقعات احتمالية، ولا يمكن التنبؤ بموعد الزلازل.

**التواصل:** ضع هنا بريدك الإلكتروني: your-email@example.com

---

# Privacy Policy — Earth Guardian

Last updated: 2026-11-28

**What we collect:** The app uses your approximate location (with your permission) or the cities you choose to show weather and nearby hazards. Your location and city list are stored on your device only.

**Who we share it with:** We run no server and collect no personal data. When checking, the coordinates of a city (not your identity) are sent to these public services to fetch data:
- Open-Meteo: weather, climate, floods, and city-name search.
- US National Weather Service (NWS): official warnings, US cities only.
- USGS (earthquakes), NASA EONET (volcanoes and storms), GDACS (tropical cyclones): fetched as public lists without sending your location.
- NASA GIBS and OpenStreetMap: satellite imagery and map tiles in the Satellite tab.
As with any internet connection, these services can see your device's IP address.

**Notifications:** Used only to deliver disaster alerts.

**Ads and analytics:** The app contains no ads or trackers.

**Deletion:** Remove a city from the Cities tab, or uninstall the app, to erase all data stored on your device.

**Disclaimer:** This app is a supplementary helper and does not replace official warnings. We do not guarantee the accuracy or timeliness of data. Forecasts are probabilistic; earthquakes cannot be predicted.

**Contact:** your-email@example.com
